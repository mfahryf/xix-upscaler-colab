"""Core contracts for the XIX-Upscaler Colab worker."""

__version__ = "0.1.0"
