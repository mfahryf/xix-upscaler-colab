from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import Any, Sequence

from . import __version__
from .errors import WorkerError
from .models import (
    RuntimeEnvironmentError,
    load_model_adapters,
    load_model_locks,
    prepare_model_assets,
    require_cuda,
)
from .pipeline import run_pipeline
from .queue import run_queue


DEFAULT_JOBS_DIR = Path("/content/drive/MyDrive/XIX-Upscaler/jobs")
DEFAULT_CACHE_DIR = Path("/content/xix-upscaler-cache")
DEFAULT_LOCKS = Path(__file__).with_name("locks.json")


def verify_environment(
    jobs_dir: Path,
    *,
    which=shutil.which,
    torch_module: Any | None = None,
) -> None:
    if not (sys.version_info >= (3, 10) and sys.version_info < (3, 13)):
        raise RuntimeEnvironmentError("Python runtime harus versi 3.10 sampai 3.12")
    if not jobs_dir.is_dir():
        raise RuntimeEnvironmentError("folder jobs Google Drive tidak ditemukan")
    for executable in ("ffmpeg", "ffprobe", "nvidia-smi"):
        if which(executable) is None:
            raise RuntimeEnvironmentError(f"{executable} tidak tersedia di runtime")
    try:
        free_bytes = shutil.disk_usage(jobs_dir).free
    except OSError as exc:
        raise RuntimeEnvironmentError("ruang penyimpanan jobs tidak dapat diperiksa") from exc
    if free_bytes < 512 * 1024 * 1024:
        raise RuntimeEnvironmentError("ruang penyimpanan tersisa kurang dari 512 MB")
    if torch_module is None:
        try:
            import torch as torch_module
        except ImportError as exc:
            raise RuntimeEnvironmentError("PyTorch tidak tersedia di runtime") from exc
    require_cuda(torch_module)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="xix-colab-worker", description="XIX-Upscaler Colab worker")
    parser.add_argument("--debug", action="store_true", help="tampilkan traceback untuk pengembang")
    subparsers = parser.add_subparsers(dest="command", required=True)

    environment = subparsers.add_parser("verify-environment", help="periksa GPU, Drive, dan FFmpeg")
    environment.add_argument("--jobs-dir", type=Path, default=DEFAULT_JOBS_DIR)

    locks = subparsers.add_parser("verify-locks", help="unduh dan verifikasi model resmi")
    locks.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR)
    locks.add_argument("--locks", type=Path, default=DEFAULT_LOCKS)

    queue = subparsers.add_parser("run-queue", help="proses antrean job Google Drive")
    queue.add_argument("--jobs-dir", type=Path, default=DEFAULT_JOBS_DIR)
    queue.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR)
    queue.add_argument("--locks", type=Path, default=DEFAULT_LOCKS)
    return parser


def _run_jobs(arguments: argparse.Namespace) -> int:
    verify_environment(arguments.jobs_dir)
    adapters: tuple[Any, Any] | None = None

    def processor(job_dir, manifest, session_id):
        nonlocal adapters
        if adapters is None:
            locks = load_model_locks(arguments.locks)
            assets = prepare_model_assets(locks, arguments.cache_dir)
            adapters = load_model_adapters(assets)
        upscaler, interpolator = adapters
        return run_pipeline(job_dir, manifest, session_id, upscaler, interpolator)

    summary = run_queue(arguments.jobs_dir, processor, worker_version=__version__)
    print(
        json.dumps(
            {
                "completed": summary.completed,
                "paused": summary.paused,
                "failed": summary.failed,
                "skipped": summary.skipped,
            },
            ensure_ascii=False,
        )
    )
    return 0 if summary.failed == 0 else 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = _parser()
    arguments = parser.parse_args(argv)
    try:
        if arguments.command == "verify-environment":
            verify_environment(arguments.jobs_dir)
            print("Environment Colab siap")
            return 0
        if arguments.command == "verify-locks":
            locks = load_model_locks(arguments.locks)
            prepare_model_assets(locks, arguments.cache_dir)
            print("Model NanoVSR dan RIFE terverifikasi")
            return 0
        if arguments.command == "run-queue":
            return _run_jobs(arguments)
        parser.error("perintah tidak dikenal")
    except KeyboardInterrupt:
        print("Worker dihentikan; job aktif dijeda pada batas aman", file=sys.stderr)
        return 130
    except WorkerError as exc:
        if arguments.debug:
            raise
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return 2
