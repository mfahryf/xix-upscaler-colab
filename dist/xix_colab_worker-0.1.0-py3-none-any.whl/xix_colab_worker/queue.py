from __future__ import annotations

import threading
import uuid
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import StatusError, WorkerError
from .manifest import JobManifest, load_manifest
from .status import (
    ACTIVE_STATES,
    JobStatus,
    claim_job,
    heartbeat,
    read_status,
    transition,
    write_status,
)


@dataclass(frozen=True)
class QueueSummary:
    completed: int = 0
    paused: int = 0
    failed: int = 0
    skipped: int = 0


def _new_session_ids() -> Iterator[str]:
    while True:
        yield str(uuid.uuid4())


class HeartbeatWatchdog:
    def __init__(
        self,
        job_dir: Path,
        session_id: str,
        *,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        interval_seconds: float = 10.0,
    ) -> None:
        if interval_seconds <= 0:
            raise ValueError("heartbeat interval must be positive")
        self._job_dir = job_dir
        self._session_id = session_id
        self._now = now
        self._interval = interval_seconds
        self._stop = threading.Event()
        self._heartbeat_written = threading.Event()
        self._thread: threading.Thread | None = None
        self._error: BaseException | None = None

    def start(self) -> None:
        if self._thread is not None:
            raise RuntimeError("heartbeat watchdog already started")
        self._thread = threading.Thread(target=self._run, name="xix-colab-heartbeat", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        while not self._stop.wait(self._interval):
            try:
                status = read_status(self._job_dir)
                if status.state not in ACTIVE_STATES or status.session_id != self._session_id:
                    return
                heartbeat(
                    self._job_dir,
                    self._session_id,
                    self._now(),
                    status.progress,
                )
                self._heartbeat_written.set()
            except BaseException as exc:
                self._error = exc
                self._stop.set()
                return

    def wait_for_heartbeat(self, timeout: float) -> bool:
        return self._heartbeat_written.wait(timeout)

    def stop(self, *, raise_error: bool = True) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self._interval * 2))
            if self._thread.is_alive():
                raise RuntimeError("heartbeat watchdog did not stop")
        if raise_error and self._error is not None:
            raise self._error


def _job_directories(jobs_dir: Path) -> list[Path]:
    if not jobs_dir.is_dir():
        raise WorkerError("folder jobs tidak ditemukan")
    jobs: list[Path] = []
    try:
        children = list(jobs_dir.iterdir())
    except OSError as exc:
        raise WorkerError("folder jobs tidak dapat dibaca") from exc
    for child in children:
        if child.is_symlink() or not child.is_dir():
            continue
        try:
            parsed = uuid.UUID(child.name)
        except ValueError:
            continue
        if str(parsed) != child.name.lower():
            continue
        jobs.append(child)
    return jobs


def _discover(
    jobs_dir: Path,
    worker_version: str,
    now: datetime,
) -> tuple[list[tuple[Path, JobManifest]], int, int]:
    runnable: list[tuple[Path, JobManifest]] = []
    skipped = 0
    invalid_failed = 0
    for job_dir in _job_directories(jobs_dir):
        try:
            manifest = load_manifest(job_dir, worker_version)
            if str(manifest.job_id) != job_dir.name.lower():
                skipped += 1
                continue
            status = read_status(job_dir)
        except WorkerError as exc:
            try:
                write_status(job_dir, JobStatus(state="failed", message=str(exc)))
                invalid_failed += 1
            except WorkerError:
                skipped += 1
            continue
        if status.state in {"completed", "failed", "cancelled"}:
            skipped += 1
            continue
        if status.state in ACTIVE_STATES and status.heartbeat_at is not None:
            if (now - status.heartbeat_at).total_seconds() < 60:
                skipped += 1
                continue
        runnable.append((job_dir, manifest))
    runnable.sort(key=lambda item: (item[1].created_at, item[0].name))
    return runnable, skipped, invalid_failed


def _pause_if_owned(job_dir: Path, session_id: str) -> None:
    try:
        status = read_status(job_dir)
        if status.session_id == session_id and status.state in ACTIVE_STATES:
            transition(job_dir, session_id, "paused", "Dijeda pada batas aman worker")
    except WorkerError:
        pass


def _fail_if_owned(job_dir: Path, session_id: str, message: str) -> None:
    try:
        status = read_status(job_dir)
        if status.session_id == session_id and status.state in ACTIVE_STATES:
            transition(job_dir, session_id, "failed", message)
    except WorkerError:
        pass


def run_queue(
    jobs_dir: Path,
    processor: Callable[[Path, JobManifest, str], Any],
    *,
    worker_version: str = "0.1.0",
    now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    session_ids: Iterator[str] | None = None,
) -> QueueSummary:
    current_time = now()
    runnable, skipped, invalid_failed = _discover(jobs_dir, worker_version, current_time)
    completed = paused = 0
    failed = invalid_failed
    ids = session_ids if session_ids is not None else _new_session_ids()
    for job_dir, manifest in runnable:
        try:
            session_id = next(ids)
        except StopIteration as exc:
            raise WorkerError("worker session ID tidak tersedia") from exc
        try:
            claim_job(job_dir, session_id, now())
        except StatusError:
            skipped += 1
            continue
        watchdog = HeartbeatWatchdog(job_dir, session_id)
        watchdog.start()
        try:
            processor(job_dir, manifest, session_id)
            watchdog.stop()
        except KeyboardInterrupt:
            watchdog.stop(raise_error=False)
            _pause_if_owned(job_dir, session_id)
            raise
        except WorkerError as exc:
            watchdog.stop(raise_error=False)
            _fail_if_owned(job_dir, session_id, str(exc))
        except Exception:
            watchdog.stop(raise_error=False)
            _fail_if_owned(job_dir, session_id, "Terjadi kegagalan internal pada worker")
        status = read_status(job_dir)
        if status.state == "completed":
            completed += 1
        elif status.state == "paused":
            paused += 1
        elif status.state == "failed":
            failed += 1
        else:
            _fail_if_owned(job_dir, session_id, "Worker berhenti tanpa status akhir")
            failed += 1
    return QueueSummary(completed, paused, failed, skipped)
