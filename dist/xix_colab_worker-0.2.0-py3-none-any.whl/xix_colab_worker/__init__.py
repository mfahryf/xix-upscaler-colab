"""Core contracts for the XIX-Upscaler Colab worker."""

__version__ = "0.2.0"
