from __future__ import annotations

import hmac
import json
import os
import re
import shutil
import uuid
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from .atomic import atomic_write_json
from .errors import MediaError
from .manifest import sha256_file
from .media import probe_media


_CHECKPOINT_RE = re.compile(r"^segment-[0-9]{5}\.(?:mp4|json)$")


@dataclass(frozen=True)
class Segment:
    index: int
    start: Fraction
    end: Fraction


@dataclass(frozen=True)
class SegmentPlan:
    duration: Fraction
    segments: tuple[Segment, ...]


@dataclass(frozen=True)
class SegmentMetadata:
    index: int
    source_start: Fraction
    source_end: Fraction
    width: int
    height: int
    fps: Fraction
    duration: Fraction
    size_bytes: int
    sha256: str

    def to_dict(self) -> dict[str, object]:
        ratio = lambda value: f"{value.numerator}/{value.denominator}"
        return {
            "index": self.index,
            "source_start": ratio(self.source_start),
            "source_end": ratio(self.source_end),
            "width": self.width,
            "height": self.height,
            "fps": ratio(self.fps),
            "duration": ratio(self.duration),
            "size_bytes": self.size_bytes,
            "sha256": self.sha256,
        }

    @classmethod
    def from_dict(cls, raw: object) -> "SegmentMetadata":
        expected = {
            "index",
            "source_start",
            "source_end",
            "width",
            "height",
            "fps",
            "duration",
            "size_bytes",
            "sha256",
        }
        if not isinstance(raw, dict) or set(raw) != expected:
            raise MediaError("checkpoint metadata does not match schema")
        try:
            metadata = cls(
                index=int(raw["index"]),
                source_start=Fraction(str(raw["source_start"])),
                source_end=Fraction(str(raw["source_end"])),
                width=int(raw["width"]),
                height=int(raw["height"]),
                fps=Fraction(str(raw["fps"])),
                duration=Fraction(str(raw["duration"])),
                size_bytes=int(raw["size_bytes"]),
                sha256=str(raw["sha256"]),
            )
        except (TypeError, ValueError, ZeroDivisionError) as exc:
            raise MediaError("checkpoint metadata is invalid") from exc
        if (
            metadata.index < 0
            or metadata.source_start < 0
            or metadata.source_end <= metadata.source_start
            or metadata.width <= 0
            or metadata.height <= 0
            or metadata.fps <= 0
            or metadata.duration <= 0
            or metadata.size_bytes <= 0
            or not re.fullmatch(r"[0-9a-f]{64}", metadata.sha256)
        ):
            raise MediaError("checkpoint metadata is invalid")
        return metadata


@dataclass(frozen=True)
class CheckpointState:
    valid_indices: tuple[int, ...]
    next_index: int
    invalid_paths: tuple[Path, ...]


def build_segment_plan(duration: Fraction, segment_seconds: int = 10) -> SegmentPlan:
    if duration <= 0 or segment_seconds <= 0:
        raise MediaError("segment plan duration must be positive")
    segments: list[Segment] = []
    start = Fraction(0)
    index = 0
    step = Fraction(segment_seconds)
    while start < duration:
        end = min(duration, start + step)
        segments.append(Segment(index, start, end))
        start = end
        index += 1
    return SegmentPlan(duration, tuple(segments))


def _names(index: int) -> tuple[str, str]:
    if index < 0 or index > 99999:
        raise MediaError("checkpoint index is outside supported range")
    return f"segment-{index:05d}.mp4", f"segment-{index:05d}.json"


def _metadata_matches_file(video: Path, metadata: SegmentMetadata) -> bool:
    try:
        media = probe_media(video)
        return (
            video.stat().st_size == metadata.size_bytes
            and hmac.compare_digest(sha256_file(video), metadata.sha256)
            and media.width == metadata.width
            and media.height == metadata.height
            and media.fps == metadata.fps
            and media.duration == metadata.duration
            and not media.has_audio
        )
    except (OSError, MediaError):
        return False


def promote_checkpoint(temp_video: Path, job_dir: Path, metadata: SegmentMetadata) -> Path:
    if not _metadata_matches_file(temp_video, metadata):
        raise MediaError("temporary segment does not match checkpoint metadata")
    checkpoint_dir = job_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    video_name, json_name = _names(metadata.index)
    target = checkpoint_dir / video_name
    temporary = checkpoint_dir / f".{video_name}.{uuid.uuid4().hex}.tmp"
    try:
        with temp_video.open("rb") as source, temporary.open("xb") as output:
            shutil.copyfileobj(source, output, length=1024 * 1024)
            output.flush()
            os.fsync(output.fileno())
        if not _metadata_matches_file(temporary, metadata):
            raise MediaError("copied checkpoint failed verification")
        os.replace(temporary, target)
        atomic_write_json(checkpoint_dir / json_name, metadata.to_dict())
        return target
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _read_metadata(path: Path) -> SegmentMetadata:
    try:
        return SegmentMetadata.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError) as exc:
        raise MediaError("checkpoint metadata cannot be read") from exc


def inspect_checkpoints(job_dir: Path, plan: SegmentPlan) -> CheckpointState:
    checkpoint_dir = job_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    valid: list[int] = []
    invalid: list[Path] = []
    resume_open = True
    for segment in plan.segments:
        video_name, json_name = _names(segment.index)
        video = checkpoint_dir / video_name
        metadata_path = checkpoint_dir / json_name
        pair_exists = video.is_file() and metadata_path.is_file()
        is_valid = False
        if pair_exists and resume_open:
            try:
                metadata = _read_metadata(metadata_path)
                is_valid = (
                    metadata.index == segment.index
                    and metadata.source_start == segment.start
                    and metadata.source_end == segment.end
                    and _metadata_matches_file(video, metadata)
                )
            except MediaError:
                is_valid = False
        if is_valid:
            valid.append(segment.index)
            continue
        resume_open = False
        if video.exists():
            invalid.append(video)
        if metadata_path.exists():
            invalid.append(metadata_path)
    return CheckpointState(tuple(valid), len(valid), tuple(invalid))


def discard_invalid_checkpoints(job_dir: Path, state: CheckpointState) -> None:
    checkpoint_dir = (job_dir / "checkpoints").resolve()
    for path in state.invalid_paths:
        try:
            parent = path.parent.resolve()
        except OSError as exc:
            raise MediaError("checkpoint cleanup path cannot be resolved") from exc
        if parent != checkpoint_dir or not _CHECKPOINT_RE.fullmatch(path.name):
            raise MediaError("checkpoint cleanup path is unsafe")
        path.unlink(missing_ok=True)
