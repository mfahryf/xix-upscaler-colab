from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Sequence

from . import __version__
from .errors import WorkerError
from .models import (
    RuntimeEnvironmentError,
    load_model_adapters,
    load_model_locks,
    prepare_model_assets,
    require_cuda,
)
from .media import stage_input
from .pipeline import run_pipeline
from .performance import PerformanceReport
from .queue import QueueSummary, run_queue


DEFAULT_JOBS_DIR = Path("/content/drive/MyDrive/XIX-Upscaler/jobs")
DEFAULT_CACHE_DIR = Path("/content/xix-upscaler-cache")
DEFAULT_LOCKS = Path(__file__).with_name("locks.json")
# Seberapa sering antrean dipindai ulang saat menunggu pekerjaan baru. Cukup
# rapat agar berkas yang baru selesai diunggah desktop cepat terlihat, cukup
# jarang agar folder Drive tidak dipindai terus-menerus.
IDLE_POLL_SECONDS = 15.0


def verify_environment(
    jobs_dir: Path,
    *,
    which=shutil.which,
    torch_module: Any | None = None,
) -> None:
    if not (sys.version_info >= (3, 10) and sys.version_info < (3, 14)):
        raise RuntimeEnvironmentError("Python runtime harus versi 3.10 sampai 3.13")
    if not jobs_dir.is_dir():
        raise RuntimeEnvironmentError("folder jobs Google Drive tidak ditemukan")
    for executable in ("ffmpeg", "ffprobe", "nvidia-smi"):
        if which(executable) is None:
            raise RuntimeEnvironmentError(f"{executable} tidak tersedia di runtime")
    try:
        free_bytes = shutil.disk_usage(jobs_dir).free
    except OSError as exc:
        raise RuntimeEnvironmentError("ruang penyimpanan jobs tidak dapat diperiksa") from exc
    if free_bytes < 512 * 1024 * 1024:
        raise RuntimeEnvironmentError("ruang penyimpanan tersisa kurang dari 512 MB")
    if torch_module is None:
        try:
            import torch as torch_module
        except ImportError as exc:
            raise RuntimeEnvironmentError("PyTorch tidak tersedia di runtime") from exc
    require_cuda(torch_module)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="xix-colab-worker", description="XIX-Upscaler Colab worker")
    parser.add_argument("--debug", action="store_true", help="tampilkan traceback untuk pengembang")
    subparsers = parser.add_subparsers(dest="command", required=True)

    environment = subparsers.add_parser("verify-environment", help="periksa GPU, Drive, dan FFmpeg")
    environment.add_argument("--jobs-dir", type=Path, default=DEFAULT_JOBS_DIR)

    locks = subparsers.add_parser("verify-locks", help="unduh dan verifikasi model resmi")
    locks.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR)
    locks.add_argument("--locks", type=Path, default=DEFAULT_LOCKS)

    queue = subparsers.add_parser("run-queue", help="proses antrean job Google Drive")
    queue.add_argument("--jobs-dir", type=Path, default=DEFAULT_JOBS_DIR)
    queue.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR)
    queue.add_argument("--locks", type=Path, default=DEFAULT_LOCKS)
    # Lama menunggu pekerjaan baru sebelum berhenti. 0 mempertahankan perilaku
    # lama: sekali sapu antrean lalu keluar.
    queue.add_argument(
        "--idle-timeout",
        type=float,
        default=0.0,
        help="detik menunggu pekerjaan baru sebelum berhenti (0 = sekali jalan)",
    )
    return parser


def _queue_exhausted(summary: QueueSummary) -> bool:
    """True saat putaran tidak menyisakan pekerjaan yang bisa dijalankan lagi.

    Dijeda atau dibatalkan berarti pengguna sedang memutuskan sesuatu, jadi
    putaran berhenti daripada menunggu pekerjaan yang tidak akan datang.
    Kegagalan tidak dihitung: desktop bisa membatalkan pekerjaan yang gagal,
    dan putaran berikutnya masih bisa mengerjakannya.
    """
    return not summary.completed and not summary.failed


def _run_jobs(arguments: argparse.Namespace) -> int:
    verify_environment(arguments.jobs_dir)
    adapters: dict[str, tuple[Any, Any]] = {}

    def processor(job_dir, manifest, session_id):
        nonlocal adapters
        performance = PerformanceReport()
        try:
            model_id = getattr(getattr(manifest, "upscale", None), "model", "nanovsr-644k")
            with performance.measure("stage_input"):
                staged_input = stage_input(
                    job_dir / manifest.input.name,
                    arguments.cache_dir / "jobs" / str(manifest.job_id) / manifest.input.name,
                    expected_size=manifest.input.size_bytes,
                    expected_sha256=manifest.input.sha256,
                )
            if model_id not in adapters:
                with performance.measure("load_models"):
                    locks = load_model_locks(arguments.locks)
                    assets = prepare_model_assets(locks, arguments.cache_dir)
                    adapters[model_id] = load_model_adapters(
                        assets,
                        model=model_id,
                    )
            upscaler, interpolator = adapters[model_id]
            return run_pipeline(
                job_dir,
                manifest,
                session_id,
                upscaler,
                interpolator,
                processing_input_path=staged_input,
                performance=performance,
            )
        except KeyboardInterrupt:
            performance.outcome = "paused"
            raise
        finally:
            performance.finish(job_dir)

    # Desktop mengunggah satu video pada satu waktu dan membuka Colab setelah
    # yang pertama selesai, jadi pekerjaan berikutnya muncul di Drive selama
    # putaran ini berjalan. Antrean karena itu dipindai ulang: tanpa itu,
    # pekerjaan baru menunggu sampai pengguna menekan Run all lagi. Model tidak
    # dimuat ulang di antara putaran karena `adapters` bertahan.
    idle_timeout = max(0.0, arguments.idle_timeout)
    idle_deadline = time.monotonic() + idle_timeout
    totals = QueueSummary()
    rounds = 0
    reported_wait = False
    try:
        while True:
            summary = run_queue(arguments.jobs_dir, processor, worker_version=__version__)
            totals = QueueSummary(
                completed=totals.completed + summary.completed,
                paused=totals.paused + summary.paused,
                cancelled=totals.cancelled + summary.cancelled,
                failed=totals.failed + summary.failed,
                # Putaran terakhir yang menentukan berapa banyak pekerjaan lama
                # yang sengaja dilewati; angka putaran sebelumnya tidak lagi
                # menggambarkan isi folder saat ini.
                skipped=summary.skipped,
            )
            rounds += 1
            if idle_timeout <= 0:
                break
            if not _queue_exhausted(summary):
                # Putaran ini mengerjakan sesuatu, jadi masa tunggu dihitung
                # ulang dari sini: sesi panjang tidak boleh terpotong di tengah.
                idle_deadline = time.monotonic() + idle_timeout
            elif time.monotonic() >= idle_deadline:
                break
            if not reported_wait:
                print(
                    f"Antrean kosong. Menunggu pekerjaan baru dari desktop; berhenti setelah "
                    f"{idle_timeout:.0f} detik tanpa pekerjaan.",
                    flush=True,
                )
                reported_wait = True
            time.sleep(IDLE_POLL_SECONDS)
    finally:
        # Ringkasan dicetak walau loop dibatalkan: putaran yang dihentikan tetap
        # punya hasil parsial yang perlu terlihat di notebook.
        if rounds:
            print(
                json.dumps(
                    {
                        "completed": totals.completed,
                        "paused": totals.paused,
                        "cancelled": totals.cancelled,
                        "failed": totals.failed,
                        "skipped": totals.skipped,
                    },
                    ensure_ascii=False,
                )
            )
    return 0 if totals.failed == 0 else 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = _parser()
    arguments = parser.parse_args(argv)
    try:
        if arguments.command == "verify-environment":
            verify_environment(arguments.jobs_dir)
            print("Environment Colab siap")
            return 0
        if arguments.command == "verify-locks":
            locks = load_model_locks(arguments.locks)
            prepare_model_assets(locks, arguments.cache_dir)
            print("Model NanoVSR, Real-ESRGAN dan RIFE terverifikasi")
            return 0
        if arguments.command == "run-queue":
            return _run_jobs(arguments)
        parser.error("perintah tidak dikenal")
    except KeyboardInterrupt:
        print("Worker dihentikan; job aktif dijeda pada batas aman", file=sys.stderr)
        return 130
    except WorkerError as exc:
        if arguments.debug:
            raise
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return 2
