"""Safe, user-facing worker errors."""


class WorkerError(Exception):
    """Base class for expected worker failures."""


class ManifestError(WorkerError):
    """The immutable job manifest is invalid or does not match its input."""


class StatusError(WorkerError):
    """The requested job status operation is invalid."""


class MediaError(WorkerError):
    """A media command failed or its result did not match the job."""
