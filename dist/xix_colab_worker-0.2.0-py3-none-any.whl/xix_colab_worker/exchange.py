from __future__ import annotations

import json
import math
import os
import re
import threading
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .errors import WorkerError


EXCHANGE_SCHEMA_VERSION = 1
STATUS_SLOT_NAMES = ("desktop-status-a.json", "desktop-status-b.json")
CONTROL_ACTIONS = frozenset({"run", "pause", "cancel"})
_STATUS_STATES = frozenset(
    {"queued", "claimed", "preparing", "processing", "paused", "failed", "cancelled", "completed"}
)
TERMINAL_STATES = frozenset({"completed", "cancelled", "failed"})
_STATUS_KEYS = {
    "schema_version",
    "revision",
    "state",
    "session_id",
    "heartbeat_at",
    "progress",
    "message",
    "metadata",
}
_STATUS_PAYLOAD_KEYS = _STATUS_KEYS - {"schema_version", "revision"}
_PROGRESS_KEYS = {"segment_index", "segment_count", "percent", "last_checkpoint"}
_CONTROL_KEYS = {"schema_version", "revision", "action"}
_OUTPUT_KEYS = {
    "name",
    "size_bytes",
    "sha256",
    "width",
    "height",
    "duration_seconds",
    "fps",
    "has_audio",
}
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_EXCHANGE_LOCK = threading.RLock()


class ExchangeError(WorkerError):
    """A pre-created Drive exchange file is missing or invalid."""


@dataclass(frozen=True)
class ControlCommand:
    revision: int
    action: str


def _nonnegative_integer(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _valid_timestamp(value: object) -> bool:
    if value is None:
        return True
    if not isinstance(value, str) or not value.endswith("Z"):
        return False
    try:
        datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError:
        return False
    return True


def _validate_progress(value: object) -> None:
    if not isinstance(value, Mapping) or set(value) != _PROGRESS_KEYS:
        raise ExchangeError("status progress fields do not match schema")
    segment_index = value["segment_index"]
    segment_count = value["segment_count"]
    percent = value["percent"]
    last_checkpoint = value["last_checkpoint"]
    if (
        not _nonnegative_integer(segment_index)
        or not _nonnegative_integer(segment_count)
        or segment_index > segment_count
        or (segment_count == 0 and segment_index != 0)
    ):
        raise ExchangeError("status segment progress is invalid")
    if (
        isinstance(percent, bool)
        or not isinstance(percent, (int, float))
        or not math.isfinite(percent)
        or not 0 <= percent <= 100
    ):
        raise ExchangeError("status percent is invalid")
    if last_checkpoint is not None and (
        not _nonnegative_integer(last_checkpoint) or last_checkpoint >= segment_count
    ):
        raise ExchangeError("status checkpoint is invalid")


def _validate_completed_output(metadata: object) -> None:
    if not isinstance(metadata, Mapping):
        raise ExchangeError("completed status requires verified output metadata")
    output = metadata.get("output")
    if not isinstance(output, Mapping) or set(output) != _OUTPUT_KEYS:
        raise ExchangeError("completed status requires verified output metadata")
    if output["name"] != "output.mp4":
        raise ExchangeError("completed output name is invalid")
    for key in ("size_bytes", "width", "height"):
        value = output[key]
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ExchangeError("completed output metadata is invalid")
    duration = output["duration_seconds"]
    if (
        isinstance(duration, bool)
        or not isinstance(duration, (int, float))
        or not math.isfinite(duration)
        or duration <= 0
    ):
        raise ExchangeError("completed output duration is invalid")
    checksum = output["sha256"]
    if not isinstance(checksum, str) or not _SHA256_RE.fullmatch(checksum):
        raise ExchangeError("completed output checksum is invalid")
    if not isinstance(output["fps"], str) or not re.fullmatch(r"[1-9][0-9]*/[1-9][0-9]*", output["fps"]):
        raise ExchangeError("completed output FPS is invalid")
    if not isinstance(output["has_audio"], bool):
        raise ExchangeError("completed output audio flag is invalid")


def _validate_status_values(raw: Mapping[str, object]) -> None:
    schema_version = raw["schema_version"]
    if (
        isinstance(schema_version, bool)
        or not isinstance(schema_version, int)
        or schema_version != EXCHANGE_SCHEMA_VERSION
    ):
        raise ExchangeError("unsupported exchange schema")
    if not _nonnegative_integer(raw["revision"]):
        raise ExchangeError("status revision is invalid")
    state = raw["state"]
    if not isinstance(state, str) or state not in _STATUS_STATES:
        raise ExchangeError("status state is invalid")
    session_id = raw["session_id"]
    if session_id is not None:
        if not isinstance(session_id, str):
            raise ExchangeError("status session ID is invalid")
        try:
            uuid.UUID(session_id)
        except (ValueError, AttributeError) as exc:
            raise ExchangeError("status session ID is invalid") from exc
    if not _valid_timestamp(raw["heartbeat_at"]):
        raise ExchangeError("status heartbeat is invalid")
    _validate_progress(raw["progress"])
    if not isinstance(raw["message"], str):
        raise ExchangeError("status message is invalid")
    metadata = raw["metadata"]
    if not isinstance(metadata, Mapping):
        raise ExchangeError("status metadata is invalid")
    if state == "completed":
        _validate_completed_output(metadata)


def _parse_status_slot(path: Path) -> dict[str, object] | None:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    except OSError as exc:
        raise ExchangeError("status slot cannot be read") from exc
    if not isinstance(raw, dict) or set(raw) != _STATUS_KEYS:
        raise ExchangeError("status slot fields do not match schema")
    _validate_status_values(raw)
    return raw


def _validate_status_payload(status: Mapping[str, object]) -> None:
    if set(status) != _STATUS_PAYLOAD_KEYS:
        raise ExchangeError("status payload fields do not match schema")
    _validate_status_values(
        {"schema_version": EXCHANGE_SCHEMA_VERSION, "revision": 0, **dict(status)}
    )


def _rewrite_existing(path: Path, payload: bytes) -> None:
    if not path.is_file():
        raise ExchangeError("required pre-created exchange file is missing")
    try:
        with path.open("r+b") as stream:
            stream.seek(0)
            stream.write(payload)
            stream.truncate()
            stream.flush()
            os.fsync(stream.fileno())
    except OSError as exc:
        raise ExchangeError("pre-created exchange file cannot be written") from exc


def _status_slot_paths(job_dir: Path) -> tuple[Path, Path]:
    return job_dir / STATUS_SLOT_NAMES[0], job_dir / STATUS_SLOT_NAMES[1]


def _validated_slots(paths: tuple[Path, Path]) -> tuple[dict[str, object] | None, ...]:
    slots = tuple(_parse_status_slot(path) for path in paths)
    revisions = [slot["revision"] for slot in slots if slot is not None]
    if len(revisions) == 2 and revisions[0] == revisions[1] and revisions[0] != 0:
        raise ExchangeError("status slot revision is not monotonic")
    for index, slot in enumerate(slots):
        if slot is not None and slot["revision"] != 0:
            expected_parity = 1 if index == 0 else 0
            if slot["revision"] % 2 != expected_parity:
                raise ExchangeError("status slot revision does not match its slot")
    return slots


def _require_status_slot_pair(job_dir: Path) -> tuple[Path, Path] | None:
    paths = _status_slot_paths(job_dir)
    exists = tuple(path.is_file() for path in paths)
    if not any(exists):
        return None
    if not all(exists):
        raise ExchangeError("both status slots must be pre-created")
    return paths


def validate_precreated_exchange(job_dir: Path) -> None:
    paths = _status_slot_paths(job_dir) + (job_dir / "control.json", job_dir / "output.mp4")
    if not all(path.is_file() for path in paths):
        raise ExchangeError("required pre-created exchange file is missing")


def read_exchange_status(job_dir: Path) -> dict[str, object] | None:
    paths = _require_status_slot_pair(job_dir)
    if paths is None:
        return None
    with _EXCHANGE_LOCK:
        valid = [slot for slot in _validated_slots(paths) if slot is not None]
        if not valid:
            return None
        return dict(max(valid, key=lambda slot: slot["revision"]))


def publish_exchange_status(job_dir: Path, status: Mapping[str, object]) -> int:
    _validate_status_payload(status)
    paths = _require_status_slot_pair(job_dir)
    if paths is None:
        return 0
    with _EXCHANGE_LOCK:
        slots = _validated_slots(paths)
        latest = max((slot for slot in slots if slot is not None),
                     key=lambda slot: slot["revision"], default=None)
        if latest is not None and latest["state"] in TERMINAL_STATES:
            if {key: latest[key] for key in _STATUS_PAYLOAD_KEYS} != dict(status):
                raise ExchangeError("terminal exchange status cannot be changed")
            return latest["revision"]
        revisions = [slot["revision"] for slot in slots if slot is not None]
        revision = max(revisions, default=0) + 1
        envelope = {
            "schema_version": EXCHANGE_SCHEMA_VERSION,
            "revision": revision,
            **dict(status),
        }
        encoded = json.dumps(envelope, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        _rewrite_existing(paths[0 if revision % 2 else 1], encoded)
        return revision


def read_control(job_dir: Path, after_revision: int) -> ControlCommand | None:
    try:
        raw = json.loads((job_dir / "control.json").read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    except OSError as exc:
        raise ExchangeError("control file cannot be read") from exc
    if not isinstance(raw, dict) or set(raw) != _CONTROL_KEYS:
        raise ExchangeError("control fields do not match schema")
    schema_version = raw["schema_version"]
    if (
        isinstance(schema_version, bool)
        or not isinstance(schema_version, int)
        or schema_version != EXCHANGE_SCHEMA_VERSION
    ):
        raise ExchangeError("unsupported control schema")
    revision = raw["revision"]
    if not _nonnegative_integer(revision):
        raise ExchangeError("control revision is invalid")
    action = raw["action"]
    if not isinstance(action, str) or action not in CONTROL_ACTIONS:
        raise ExchangeError("control action is invalid")
    if revision <= after_revision:
        return None
    return ControlCommand(revision=revision, action=action)


def copy_into_precreated(source: Path, target: Path, chunk_size: int = 1024 * 1024) -> None:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if not target.is_file():
        raise ExchangeError("required pre-created output is missing")
    try:
        with source.open("rb") as input_stream, target.open("r+b") as output_stream:
            output_stream.seek(0)
            while chunk := input_stream.read(chunk_size):
                output_stream.write(chunk)
            output_stream.truncate()
            output_stream.flush()
            os.fsync(output_stream.fileno())
    except OSError as exc:
        raise ExchangeError("pre-created output cannot be filled") from exc
