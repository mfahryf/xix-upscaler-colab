from __future__ import annotations

import re
from bisect import bisect_left
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterator, Sequence

from .errors import MediaError


SUPPORTED_TARGETS = {
    "23.976": Fraction(24000, 1001),
    "24": Fraction(24, 1),
    "25": Fraction(25, 1),
    "29.97": Fraction(30000, 1001),
    "30": Fraction(30, 1),
    "48": Fraction(48, 1),
    "50": Fraction(50, 1),
    "59.94": Fraction(60000, 1001),
    "60": Fraction(60, 1),
}
_RATIO_RE = re.compile(r"^[0-9]+/[0-9]+$")
_INTEGER_RE = re.compile(r"^[0-9]+$")


@dataclass(frozen=True)
class FrameRequest:
    left_index: int
    right_index: int
    timestep: Fraction
    use_original: bool


def parse_fps(value: str) -> Fraction:
    if not isinstance(value, str):
        raise MediaError("FPS must be text")
    if value in SUPPORTED_TARGETS:
        return SUPPORTED_TARGETS[value]
    if not (_RATIO_RE.fullmatch(value) or _INTEGER_RE.fullmatch(value)):
        raise MediaError("FPS must be a positive integer, supported label, or exact ratio")
    try:
        result = Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise MediaError("FPS ratio is invalid") from exc
    if result <= 0:
        raise MediaError("FPS must be positive")
    return result


def validate_target(source: Fraction, target: Fraction) -> None:
    if source <= 0:
        raise MediaError("source FPS must be positive")
    if target not in SUPPORTED_TARGETS.values() or target > 60:
        raise MediaError("target FPS is unsupported")
    if target <= source:
        raise MediaError("target FPS must be higher than source FPS")


def output_timestamps(duration: Fraction, target: Fraction) -> Iterator[Fraction]:
    if duration <= 0 or target <= 0:
        raise MediaError("duration and target FPS must be positive")
    frame = 0
    while Fraction(frame, 1) / target < duration:
        yield Fraction(frame, 1) / target
        frame += 1


def map_target_timestamp(source_pts: Sequence[Fraction], target_pts: Fraction) -> FrameRequest:
    if len(source_pts) < 2:
        raise MediaError("at least two source timestamps are required")
    if any(right <= left for left, right in zip(source_pts, source_pts[1:])):
        raise MediaError("source timestamps must be strictly increasing")
    if target_pts < source_pts[0] or target_pts > source_pts[-1]:
        raise MediaError("target timestamp is outside the source timeline")
    right_index = bisect_left(source_pts, target_pts)
    if right_index < len(source_pts) and source_pts[right_index] == target_pts:
        return FrameRequest(right_index, right_index, Fraction(0), True)
    if right_index == 0 or right_index == len(source_pts):
        raise MediaError("target timestamp cannot be mapped")
    left_index = right_index - 1
    timestep = (target_pts - source_pts[left_index]) / (
        source_pts[right_index] - source_pts[left_index]
    )
    if not 0 < timestep < 1:
        raise MediaError("interpolation timestep is outside the valid range")
    return FrameRequest(left_index, right_index, timestep, False)
