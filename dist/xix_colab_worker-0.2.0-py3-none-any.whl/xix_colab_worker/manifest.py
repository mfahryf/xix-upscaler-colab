from __future__ import annotations

import hashlib
import hmac
import json
import math
import re
import uuid
from dataclasses import dataclass
from datetime import datetime
from fractions import Fraction
from pathlib import Path
from typing import Mapping

from .errors import ManifestError


WORKER_VERSION = "0.2.0"
MANIFEST_SCHEMA_VERSION = 2
EXCHANGE_PROTOCOL = "drive-slots-v1"
MAX_INPUT_BYTES = 100 * 1024 * 1024
MAX_DURATION_SECONDS = 60.0
SUPPORTED_INPUT_EXTENSIONS = frozenset({"mp4", "mov", "webm", "mkv", "m4v", "ts"})
SUPPORTED_TARGET_RATIOS = frozenset(
    {
        "24000/1001",
        "24/1",
        "25/1",
        "30000/1001",
        "30/1",
        "48/1",
        "50/1",
        "60000/1001",
        "60/1",
    }
)
_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


@dataclass(frozen=True)
class InputSpec:
    name: str
    extension: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class SourceSpec:
    width: int
    height: int
    duration_seconds: float
    time_base: Fraction
    nominal_fps: Fraction
    has_audio: bool


@dataclass(frozen=True)
class UpscaleSpec:
    model: str
    scale: int


@dataclass(frozen=True)
class OutputSpec:
    format: str
    video_codec: str
    suffix: str


@dataclass(frozen=True)
class JobManifest:
    schema_version: int
    worker_version: str
    exchange_protocol: str
    job_id: uuid.UUID
    created_at: datetime
    input: InputSpec
    source: SourceSpec
    upscale: UpscaleSpec
    interpolation: Fraction | None
    mute_audio: bool
    output: OutputSpec


def _require_mapping(value: object, name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ManifestError(f"{name} must be an object")
    return value


def _require_keys(raw: Mapping[str, object], expected: set[str], name: str) -> None:
    if set(raw) != expected:
        raise ManifestError(f"{name} fields do not match schema")


def _positive_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ManifestError(f"{name} must be a positive integer")
    return value


def _positive_number(value: object, name: str) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise ManifestError(f"{name} must be positive")
    return float(value)


def _parse_positive_fraction(value: object, name: str) -> Fraction:
    if not isinstance(value, str):
        raise ManifestError(f"{name} must be a ratio string")
    try:
        result = Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ManifestError(f"{name} is not a valid ratio") from exc
    if result <= 0:
        raise ManifestError(f"{name} must be positive")
    return result


def _parse_created_at(value: object) -> datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ManifestError("created_at must be a UTC timestamp")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as exc:
        raise ManifestError("created_at must be a UTC timestamp") from exc
    return parsed


def validate_manifest_dict(raw: Mapping[str, object], worker_version: str) -> JobManifest:
    root = _require_mapping(raw, "manifest")
    _require_keys(
        root,
        {
            "schema_version",
            "worker_version",
            "exchange_protocol",
            "job_id",
            "created_at",
            "input",
            "source",
            "upscale",
            "interpolation",
            "mute_audio",
            "output",
        },
        "manifest",
    )
    if root["schema_version"] != MANIFEST_SCHEMA_VERSION:
        raise ManifestError("unsupported manifest schema")
    if root["worker_version"] != worker_version:
        raise ManifestError("worker version does not match manifest")
    exchange_protocol = root["exchange_protocol"]
    if not isinstance(exchange_protocol, str) or exchange_protocol != EXCHANGE_PROTOCOL:
        raise ManifestError("unsupported exchange protocol")
    try:
        job_id = uuid.UUID(str(root["job_id"]))
    except (ValueError, AttributeError) as exc:
        raise ManifestError("job_id must be a UUID") from exc

    input_raw = _require_mapping(root["input"], "input")
    _require_keys(input_raw, {"name", "extension", "size_bytes", "sha256"}, "input")
    name = input_raw["name"]
    extension = input_raw["extension"]
    if (
        not isinstance(name, str)
        or not name
        or "/" in name
        or "\\" in name
        or Path(name).name != name
    ):
        raise ManifestError("input name must be one relative file name")
    if not isinstance(extension, str):
        raise ManifestError("input extension must be text")
    normalized_extension = extension.lower()
    if normalized_extension not in SUPPORTED_INPUT_EXTENSIONS:
        raise ManifestError("input extension is unsupported")
    if Path(name).suffix.lower() != f".{normalized_extension}":
        raise ManifestError("input extension does not match its name")
    size_bytes = _positive_int(input_raw["size_bytes"], "input size")
    if size_bytes > MAX_INPUT_BYTES:
        raise ManifestError("input exceeds the 100 MB limit")
    checksum = input_raw["sha256"]
    if not isinstance(checksum, str) or not _SHA256_RE.fullmatch(checksum):
        raise ManifestError("input checksum must be SHA-256")

    source_raw = _require_mapping(root["source"], "source")
    _require_keys(
        source_raw,
        {"width", "height", "duration_seconds", "time_base", "nominal_fps", "has_audio"},
        "source",
    )
    duration = _positive_number(source_raw["duration_seconds"], "source duration")
    if duration > MAX_DURATION_SECONDS:
        raise ManifestError("source exceeds the 1 minute limit")
    source_fps = _parse_positive_fraction(source_raw["nominal_fps"], "source FPS")
    has_audio = source_raw["has_audio"]
    if not isinstance(has_audio, bool):
        raise ManifestError("source audio flag must be boolean")

    upscale_raw = _require_mapping(root["upscale"], "upscale")
    _require_keys(upscale_raw, {"model", "scale"}, "upscale")
    upscale_profiles = {
        "nanovsr-644k": 4,
        "realesrgan-x2plus": 2,
        "realesrgan-x4plus": 4,
    }
    upscale_model = upscale_raw["model"]
    upscale_scale = upscale_raw["scale"]
    if (
        not isinstance(upscale_model, str)
        or isinstance(upscale_scale, bool)
        or not isinstance(upscale_scale, int)
        or upscale_profiles.get(upscale_model) != upscale_scale
    ):
        raise ManifestError("unsupported upscale profile")

    interpolation_raw = root["interpolation"]
    if interpolation_raw == "off":
        interpolation = None
    elif isinstance(interpolation_raw, str) and interpolation_raw in SUPPORTED_TARGET_RATIOS:
        interpolation = Fraction(interpolation_raw)
        if interpolation <= source_fps:
            raise ManifestError("target FPS must be higher than source FPS")
    else:
        raise ManifestError("unsupported target FPS")

    mute_audio = root["mute_audio"]
    if not isinstance(mute_audio, bool):
        raise ManifestError("mute_audio must be boolean")

    output_raw = _require_mapping(root["output"], "output")
    _require_keys(output_raw, {"format", "video_codec", "suffix"}, "output")
    if output_raw != {"format": "mp4", "video_codec": "h264", "suffix": "-colab"}:
        raise ManifestError("unsupported output profile")

    return JobManifest(
        schema_version=MANIFEST_SCHEMA_VERSION,
        worker_version=worker_version,
        exchange_protocol=exchange_protocol,
        job_id=job_id,
        created_at=_parse_created_at(root["created_at"]),
        input=InputSpec(name, normalized_extension, size_bytes, checksum.lower()),
        source=SourceSpec(
            width=_positive_int(source_raw["width"], "source width"),
            height=_positive_int(source_raw["height"], "source height"),
            duration_seconds=duration,
            time_base=_parse_positive_fraction(source_raw["time_base"], "source time base"),
            nominal_fps=source_fps,
            has_audio=has_audio,
        ),
        upscale=UpscaleSpec(upscale_model, upscale_scale),
        interpolation=interpolation,
        mute_audio=mute_audio,
        output=OutputSpec("mp4", "h264", "-colab"),
    )


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest(job_dir: Path, worker_version: str) -> JobManifest:
    try:
        raw = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManifestError("manifest.json cannot be read") from exc
    manifest = validate_manifest_dict(_require_mapping(raw, "manifest"), worker_version)
    input_path = job_dir / manifest.input.name
    try:
        actual_size = input_path.stat().st_size
        actual_checksum = sha256_file(input_path)
    except OSError as exc:
        raise ManifestError("input file cannot be read") from exc
    if actual_size != manifest.input.size_bytes:
        raise ManifestError("input size does not match manifest")
    if not hmac.compare_digest(actual_checksum, manifest.input.sha256):
        raise ManifestError("input checksum does not match manifest")
    return manifest
