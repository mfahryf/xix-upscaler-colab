from __future__ import annotations

import hmac
import json
import os
import shutil
import subprocess
import uuid
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from .errors import MediaError
from .fps import parse_fps
from .manifest import sha256_file


COMMAND_TIMEOUT_SECONDS = 120


@dataclass(frozen=True)
class MediaInfo:
    width: int
    height: int
    duration: Fraction
    fps: Fraction
    time_base: Fraction
    rotation: int
    display_matrix: str | None
    has_audio: bool
    video_codec: str
    container_format: str


@dataclass(frozen=True)
class VerifiedOutput:
    media: MediaInfo
    size_bytes: int
    sha256: str


def _require_tool(name: str) -> str:
    executable = shutil.which(name)
    if executable is None:
        raise MediaError(f"{name} is unavailable")
    return executable


def _run(arguments: list[str], purpose: str, timeout: int = COMMAND_TIMEOUT_SECONDS) -> subprocess.CompletedProcess[bytes]:
    try:
        result = subprocess.run(
            arguments,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MediaError(f"{purpose} could not be completed") from exc
    if result.returncode != 0:
        raise MediaError(f"{purpose} failed")
    return result


def _fraction(value: object, field_name: str) -> Fraction:
    if not isinstance(value, str):
        raise MediaError(f"media {field_name} is missing")
    try:
        result = Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise MediaError(f"media {field_name} is invalid") from exc
    if result <= 0:
        raise MediaError(f"media {field_name} must be positive")
    return result


def stage_input(
    source: Path,
    destination: Path,
    *,
    expected_size: int,
    expected_sha256: str,
) -> Path:
    """Copy a Drive-mounted input to local storage before random-access media work."""
    try:
        if (
            destination.is_file()
            and destination.stat().st_size == expected_size
            and hmac.compare_digest(sha256_file(destination), expected_sha256.lower())
        ):
            return destination
    except OSError:
        pass

    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as input_stream, temporary.open("xb") as output_stream:
            shutil.copyfileobj(input_stream, output_stream, length=1024 * 1024)
            output_stream.flush()
            os.fsync(output_stream.fileno())
        if (
            temporary.stat().st_size != expected_size
            or not hmac.compare_digest(sha256_file(temporary), expected_sha256.lower())
        ):
            raise MediaError("input staging checksum does not match manifest")
        os.replace(temporary, destination)
        return destination
    except MediaError:
        temporary.unlink(missing_ok=True)
        raise
    except OSError as exc:
        temporary.unlink(missing_ok=True)
        raise MediaError("input cannot be staged locally") from exc


def probe_media(path: Path) -> MediaInfo:
    ffprobe = _require_tool("ffprobe")
    result = _run(
        [
            ffprobe,
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(path),
        ],
        "media probe",
        timeout=30,
    )
    if len(result.stdout) > 1024 * 1024:
        raise MediaError("media probe returned too much metadata")
    try:
        raw = json.loads(result.stdout.decode("utf-8"))
        streams = raw["streams"]
        video = next(stream for stream in streams if stream.get("codec_type") == "video")
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError, StopIteration, TypeError) as exc:
        raise MediaError("media probe returned invalid metadata") from exc
    if not isinstance(streams, list) or not isinstance(video, dict):
        raise MediaError("media probe returned invalid metadata")
    try:
        width = int(video["width"])
        height = int(video["height"])
    except (KeyError, TypeError, ValueError) as exc:
        raise MediaError("media dimensions are invalid") from exc
    if width <= 0 or height <= 0:
        raise MediaError("media dimensions must be positive")
    fps_text = video.get("avg_frame_rate")
    if fps_text in (None, "0/0", "0/1"):
        fps_text = video.get("r_frame_rate")
    fps = parse_fps(fps_text)
    time_base = _fraction(video.get("time_base"), "time base")
    duration_text = video.get("duration") or raw.get("format", {}).get("duration")
    duration = _fraction(duration_text, "duration")
    tags = video.get("tags") if isinstance(video.get("tags"), dict) else {}
    rotation = int(tags.get("rotate", 0)) if tags else 0
    display_matrix: str | None = None
    side_data_list = video.get("side_data_list", [])
    if isinstance(side_data_list, list):
        for side_data in side_data_list:
            if not isinstance(side_data, dict):
                continue
            if "rotation" in side_data:
                rotation = int(side_data["rotation"])
            if isinstance(side_data.get("displaymatrix"), str):
                display_matrix = side_data["displaymatrix"]
    return MediaInfo(
        width=width,
        height=height,
        duration=duration,
        fps=fps,
        time_base=time_base,
        rotation=rotation % 360,
        display_matrix=display_matrix,
        has_audio=any(isinstance(stream, dict) and stream.get("codec_type") == "audio" for stream in streams),
        video_codec=str(video.get("codec_name", "")),
        container_format=str(raw.get("format", {}).get("format_name", "")),
    )


def probe_frame_timestamps(path: Path) -> tuple[Fraction, ...]:
    ffprobe = _require_tool("ffprobe")
    result = _run(
        [
            ffprobe,
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "frame=best_effort_timestamp_time",
            "-of",
            "json",
            str(path),
        ],
        "frame timestamp probe",
        timeout=COMMAND_TIMEOUT_SECONDS,
    )
    if len(result.stdout) > 256 * 1024 * 1024:
        raise MediaError("frame timestamp probe returned too much metadata")
    try:
        raw = json.loads(result.stdout.decode("utf-8"))
        frames = raw["frames"]
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError) as exc:
        raise MediaError("frame timestamp probe returned invalid metadata") from exc
    if not isinstance(frames, list) or not frames:
        raise MediaError("video has no frame timestamps")
    timestamps: list[Fraction] = []
    for frame in frames:
        if not isinstance(frame, dict):
            raise MediaError("frame timestamp probe returned invalid metadata")
        value = frame.get("best_effort_timestamp_time")
        if not isinstance(value, str):
            raise MediaError("video frame timestamp is missing")
        try:
            timestamp = Fraction(value)
        except (ValueError, ZeroDivisionError) as exc:
            raise MediaError("video frame timestamp is invalid") from exc
        if timestamp < 0 or (timestamps and timestamp <= timestamps[-1]):
            raise MediaError("video frame timestamps are not strictly increasing")
        timestamps.append(timestamp)
    return tuple(timestamps)


def make_synthetic_video(path: Path, *, fps: str, duration: float, audio: bool) -> None:
    ffmpeg = _require_tool("ffmpeg")
    rate = parse_fps(fps)
    rate_text = f"{rate.numerator}/{rate.denominator}"
    arguments = [
        ffmpeg,
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-f",
        "lavfi",
        "-i",
        f"testsrc2=size=32x24:rate={rate_text}:duration={duration}",
    ]
    if audio:
        arguments.extend(
            [
                "-f",
                "lavfi",
                "-i",
                f"sine=frequency=1000:sample_rate=44100:duration={duration}",
                "-map",
                "0:v:0",
                "-map",
                "1:a:0",
            ]
        )
    arguments.extend(["-c:v", "libx264", "-pix_fmt", "yuv420p"])
    if audio:
        arguments.extend(["-c:a", "aac", "-shortest"])
    else:
        arguments.append("-an")
    arguments.append(str(path))
    _run(arguments, "synthetic media creation", timeout=30)


def mux_audio(source: Path, silent_video: Path, output: Path, mute: bool) -> None:
    ffmpeg = _require_tool("ffmpeg")
    common = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
    if mute:
        _run(
            common
            + ["-i", str(silent_video), "-map", "0:v:0", "-c:v", "copy", "-an", str(output)],
            "muted video mux",
        )
    else:
        base = common + [
            "-i",
            str(source),
            "-i",
            str(silent_video),
            "-map",
            "1:v:0",
            "-map",
            "0:a:0?",
            "-c:v",
            "copy",
        ]
        try:
            _run(base + ["-c:a", "copy", "-shortest", str(output)], "video audio mux")
        except MediaError:
            _run(
                base + ["-c:a", "aac", "-b:a", "160k", "-shortest", str(output)],
                "video audio mux",
            )
    actual = probe_media(output)
    expected_audio = probe_media(source).has_audio and not mute
    if actual.has_audio != expected_audio:
        raise MediaError("muxed output audio does not match Mute setting")


def verify_output(
    input_info: MediaInfo,
    output: Path,
    target_fps: Fraction | None,
    mute: bool,
    *,
    expected_sha256: str | None = None,
) -> VerifiedOutput:
    try:
        size_bytes = output.stat().st_size
    except OSError as exc:
        raise MediaError("output cannot be read") from exc
    if size_bytes <= 0:
        raise MediaError("output is empty")
    media = probe_media(output)
    if (media.width, media.height) != (input_info.width * 4, input_info.height * 4):
        raise MediaError("output dimensions are not exactly 4x")
    expected_fps = target_fps or input_info.fps
    if media.fps != expected_fps:
        raise MediaError("output FPS does not match target")
    if abs(media.duration - input_info.duration) >= Fraction(1, 1) / expected_fps:
        raise MediaError("output duration differs by at least one target frame")
    if media.rotation != input_info.rotation:
        raise MediaError("output orientation does not match input")
    expected_audio = input_info.has_audio and not mute
    if media.has_audio != expected_audio:
        raise MediaError("output audio does not match Mute setting")
    if media.video_codec != "h264":
        raise MediaError("output video codec is not H.264")
    if "mp4" not in media.container_format.split(","):
        raise MediaError("output container is not MP4")
    checksum = sha256_file(output)
    if expected_sha256 is not None and not hmac.compare_digest(checksum, expected_sha256.lower()):
        raise MediaError("output checksum does not match expected value")
    return VerifiedOutput(media=media, size_bytes=size_bytes, sha256=checksum)
