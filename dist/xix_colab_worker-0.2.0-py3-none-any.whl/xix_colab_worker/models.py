from __future__ import annotations

import hashlib
import hmac
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import uuid
import zipfile
from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path, PurePosixPath
from types import ModuleType
from typing import Any
from urllib.parse import urlparse
from urllib.request import urlopen

from .errors import WorkerError


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_REVISION_RE = re.compile(r"^(?:[0-9a-f]{40}|v?[0-9]+(?:\.[0-9]+)*(?:\.lite)?)$")
_ALLOWED_HOSTS = frozenset(
    {
        "codeload.github.com",
        "github.com",
        "drive.usercontent.google.com",
    }
)
_RUNTIME_KEYS = frozenset({"python", "torch", "numpy", "opencv"})


class ModelError(WorkerError):
    """A model asset or inference result is invalid."""


class RuntimeEnvironmentError(ModelError):
    """The runtime cannot execute the configured GPU models."""


class ModelOutOfMemory(ModelError):
    """CUDA ran out of memory while processing a temporal chunk."""


@dataclass(frozen=True)
class AssetLock:
    name: str
    url: str
    revision: str
    filename: str
    size_bytes: int
    sha256: str
    kind: str


@dataclass(frozen=True)
class ModelLocks:
    schema_version: int
    runtime: Mapping[str, str]
    assets: Mapping[str, AssetLock]


@dataclass(frozen=True)
class PreparedModelAssets:
    nanovsr_source: Path
    nanovsr_weights: Path
    rife_source: Path
    rife_model: Path


def _validate_asset(name: str, raw: object) -> AssetLock:
    if not isinstance(raw, Mapping) or set(raw) != {
        "url",
        "revision",
        "filename",
        "size_bytes",
        "sha256",
        "kind",
    }:
        raise ModelError(f"model lock {name} does not match schema")
    url = raw["url"]
    revision = raw["revision"]
    filename = raw["filename"]
    size_bytes = raw["size_bytes"]
    checksum = raw["sha256"]
    kind = raw["kind"]
    parsed = urlparse(url) if isinstance(url, str) else None
    if parsed is None or parsed.scheme != "https" or parsed.hostname not in _ALLOWED_HOSTS:
        raise ModelError(f"model lock {name} uses an untrusted URL")
    if not isinstance(revision, str) or not _REVISION_RE.fullmatch(revision):
        raise ModelError(f"model lock {name} has an invalid revision")
    if (
        not isinstance(filename, str)
        or not filename
        or Path(filename).name != filename
        or "/" in filename
        or "\\" in filename
    ):
        raise ModelError(f"model lock {name} has an unsafe filename")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or size_bytes <= 0:
        raise ModelError(f"model lock {name} has an invalid size")
    if not isinstance(checksum, str) or not _SHA256_RE.fullmatch(checksum):
        raise ModelError(f"model lock {name} has an invalid checksum")
    if kind not in {"file", "zip"}:
        raise ModelError(f"model lock {name} has an invalid kind")
    return AssetLock(name, url, revision, filename, size_bytes, checksum, kind)


def load_model_locks(path: Path) -> ModelLocks:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelError("model lock file cannot be read") from exc
    if not isinstance(raw, Mapping) or set(raw) != {"schema_version", "runtime", "assets"}:
        raise ModelError("model lock file does not match schema")
    if raw["schema_version"] != 1:
        raise ModelError("model lock schema is unsupported")
    runtime = raw["runtime"]
    if (
        not isinstance(runtime, Mapping)
        or set(runtime) != _RUNTIME_KEYS
        or not all(isinstance(value, str) and value for value in runtime.values())
    ):
        raise ModelError("model runtime policy does not match schema")
    assets_raw = raw["assets"]
    if not isinstance(assets_raw, Mapping) or not assets_raw:
        raise ModelError("model assets are missing")
    assets = {str(name): _validate_asset(str(name), value) for name, value in assets_raw.items()}
    return ModelLocks(1, dict(runtime), assets)


def _file_matches(path: Path, asset: AssetLock) -> bool:
    try:
        if path.stat().st_size != asset.size_bytes:
            return False
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
        return hmac.compare_digest(digest.hexdigest(), asset.sha256)
    except OSError:
        return False


def ensure_asset(
    asset: AssetLock,
    cache_dir: Path,
    *,
    open_url: Callable[[str], Any] = urlopen,
) -> Path:
    downloads = cache_dir / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    target = downloads / asset.filename
    if _file_matches(target, asset):
        return target
    target.unlink(missing_ok=True)
    last_error: Exception | None = None
    for _attempt in range(2):
        temporary = downloads / f".{asset.filename}.{uuid.uuid4().hex}.tmp"
        try:
            digest = hashlib.sha256()
            size = 0
            with open_url(asset.url) as response, temporary.open("xb") as output:
                while chunk := response.read(1024 * 1024):
                    size += len(chunk)
                    digest.update(chunk)
                    output.write(chunk)
                output.flush()
                os.fsync(output.fileno())
            if size != asset.size_bytes or not hmac.compare_digest(digest.hexdigest(), asset.sha256):
                raise ModelError(f"{asset.name} size or checksum does not match lock")
            os.replace(temporary, target)
            return target
        except Exception as exc:
            temporary.unlink(missing_ok=True)
            target.unlink(missing_ok=True)
            last_error = exc
    if isinstance(last_error, ModelError):
        raise last_error
    raise ModelError(f"{asset.name} could not be downloaded") from last_error


def _is_junk_member(path: PurePosixPath) -> bool:
    return "__MACOSX" in path.parts or "__pycache__" in path.parts or path.name in {".DS_Store"}


def extract_archive(archive: Path, destination: Path, *, expected_sha256: str) -> Path:
    marker = destination / ".xix-asset-sha256"
    if destination.is_dir():
        try:
            if marker.read_text(encoding="ascii").strip() == expected_sha256:
                return destination
        except OSError:
            pass
        raise ModelError("existing extracted model directory does not match lock")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.parent / f".{destination.name}.{uuid.uuid4().hex}.tmp"
    temporary.mkdir()
    try:
        with zipfile.ZipFile(archive) as zipped:
            for info in zipped.infolist():
                normalized = info.filename.replace("\\", "/")
                member = PurePosixPath(normalized)
                if member.is_absolute() or ".." in member.parts or not member.parts:
                    raise ModelError("model archive contains an unsafe path")
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ModelError("model archive contains a symbolic link")
                if _is_junk_member(member):
                    continue
                target = temporary.joinpath(*member.parts)
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(info) as source, target.open("xb") as output:
                    shutil.copyfileobj(source, output)
        (temporary / ".xix-asset-sha256").write_text(expected_sha256 + "\n", encoding="ascii")
        os.replace(temporary, destination)
        return destination
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def prepare_model_assets(locks: ModelLocks, cache_dir: Path) -> PreparedModelAssets:
    required = {"nanovsr_source", "nanovsr_644k", "rife_source", "rife_425_lite"}
    if set(locks.assets) != required:
        raise ModelError("model asset set does not match worker profile")
    downloaded = {name: ensure_asset(asset, cache_dir) for name, asset in locks.assets.items()}
    extracted = cache_dir / "extracted"
    nano_source = extract_archive(
        downloaded["nanovsr_source"],
        extracted / f"nanovsr-{locks.assets['nanovsr_source'].sha256[:12]}",
        expected_sha256=locks.assets["nanovsr_source"].sha256,
    )
    rife_source = extract_archive(
        downloaded["rife_source"],
        extracted / f"rife-source-{locks.assets['rife_source'].sha256[:12]}",
        expected_sha256=locks.assets["rife_source"].sha256,
    )
    rife_model = extract_archive(
        downloaded["rife_425_lite"],
        extracted / f"rife-model-{locks.assets['rife_425_lite'].sha256[:12]}",
        expected_sha256=locks.assets["rife_425_lite"].sha256,
    )
    return PreparedModelAssets(nano_source, downloaded["nanovsr_644k"], rife_source, rife_model)


def require_cuda(torch_module: Any) -> None:
    try:
        available = bool(torch_module.cuda.is_available())
    except Exception as exc:
        raise RuntimeEnvironmentError("CUDA availability could not be checked") from exc
    if not available:
        raise RuntimeEnvironmentError("GPU CUDA tidak tersedia; pilih runtime GPU di Colab")


def _is_oom(error: BaseException) -> bool:
    return "out of memory" in str(error).lower() and "cuda" in str(error).lower()


def _frame_array(frames: Sequence[Any]) -> Any:
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeEnvironmentError("NumPy is unavailable") from exc
    array = np.asarray(frames)
    if array.ndim != 4 or array.shape[0] == 0 or array.shape[-1] != 3 or array.dtype != np.uint8:
        raise ModelError("video frames must be non-empty RGB uint8 arrays")
    return np.ascontiguousarray(array)


def _validated_output(output: Any, expected_shape: tuple[int, ...]) -> Any:
    import numpy as np

    array = np.asarray(output)
    if array.shape != expected_shape or not np.issubdtype(array.dtype, np.number):
        raise ModelError("model output shape does not match the requested frames")
    if not np.isfinite(array).all():
        raise ModelError("model output contains non-finite values")
    if array.dtype != np.uint8:
        array = np.clip(np.rint(array), 0, 255).astype(np.uint8)
    return np.ascontiguousarray(array)


class NanoVSRUpscaler:
    scale = 4

    def __init__(self, runner: Callable[[Any], Any]):
        self._runner = runner

    def upscale_sequence(self, frames: Sequence[Any]) -> Any:
        source = _frame_array(frames)
        expected = (source.shape[0], source.shape[1] * 4, source.shape[2] * 4, 3)
        try:
            output = self._runner(source)
        except Exception as exc:
            if _is_oom(exc):
                raise ModelOutOfMemory("CUDA kehabisan memori saat menjalankan NanoVSR") from exc
            raise
        return _validated_output(output, expected)


class RifeInterpolator:
    def __init__(self, runner: Callable[[Any, Any, float], Any]):
        self._runner = runner

    def interpolate(self, left: Any, right: Any, timestep: Fraction | float) -> Any:
        source = _frame_array([left, right])
        value = float(timestep)
        if not 0 < value < 1:
            raise ModelError("RIFE timestep must be between 0 and 1")
        try:
            output = self._runner(source[0], source[1], value)
        except Exception as exc:
            if _is_oom(exc):
                raise ModelOutOfMemory("CUDA kehabisan memori saat menjalankan RIFE") from exc
            raise
        return _validated_output(output, tuple(source[0].shape))


def _single_child_root(extracted: Path, required: Path) -> Path:
    candidates = [path for path in extracted.iterdir() if path.is_dir() and (path / required).is_file()]
    if len(candidates) != 1:
        raise ModelError(f"model source does not contain {required.as_posix()}")
    return candidates[0]


@contextmanager
def _python_paths(paths: Sequence[Path]):
    values = [str(path) for path in paths]
    sys.path[:0] = values
    try:
        yield
    finally:
        for value in values:
            try:
                sys.path.remove(value)
            except ValueError:
                pass


def _load_module(name: str, path: Path, search_paths: Sequence[Path]) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ModelError(f"model module {path.name} cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    with _python_paths(search_paths):
        spec.loader.exec_module(module)
    return module


def _torch_state(torch_module: Any, path: Path) -> Mapping[str, Any]:
    try:
        state = torch_module.load(path, map_location="cpu", weights_only=True)
    except Exception as exc:
        raise ModelError("model checkpoint cannot be loaded safely") from exc
    if isinstance(state, Mapping):
        for key in ("params_ema", "params", "model_state_dict"):
            nested = state.get(key)
            if isinstance(nested, Mapping):
                return nested
        return state
    raise ModelError("model checkpoint does not contain a state dictionary")


def _nanovsr_runner(assets: PreparedModelAssets, torch_module: Any, *, use_fp16: bool) -> Callable[[Any], Any]:
    import numpy as np

    source_root = _single_child_root(assets.nanovsr_source, Path("models/nanovsr.py"))
    module = _load_module(
        "xix_vendor_nanovsr",
        source_root / "models" / "nanovsr.py",
        [source_root],
    )
    model = module.NanoVSR(num_feat=48, num_blocks=12, deploy=False)
    model.load_state_dict(_torch_state(torch_module, assets.nanovsr_weights), strict=True)
    model.switch_to_deploy()
    model.eval().to("cuda")

    def run(frames: Any) -> Any:
        tensor = torch_module.from_numpy(np.ascontiguousarray(frames)).permute(0, 3, 1, 2)
        tensor = tensor.unsqueeze(0).to("cuda", non_blocking=True).float().div_(255.0)
        with torch_module.inference_mode(), torch_module.autocast(
            device_type="cuda", dtype=torch_module.float16, enabled=use_fp16
        ):
            output = model(tensor)
        output = output.squeeze(0).clamp_(0, 1).mul_(255).round().byte()
        return output.permute(0, 2, 3, 1).cpu().numpy()

    return run


def _rife_runner(assets: PreparedModelAssets, torch_module: Any, *, use_fp16: bool) -> Callable[[Any, Any, float], Any]:
    import numpy as np

    source_root = _single_child_root(assets.rife_source, Path("model/warplayer.py"))
    train_log = assets.rife_model / "train_log"
    ifnet_path = train_log / "IFNet_HDv3.py"
    weights_path = train_log / "flownet.pkl"
    if not ifnet_path.is_file() or not weights_path.is_file():
        raise ModelError("RIFE model archive is incomplete")
    module = _load_module("xix_vendor_rife_ifnet", ifnet_path, [source_root, assets.rife_model])
    model = module.IFNet()
    state = _torch_state(torch_module, weights_path)
    converted = {}
    for key, value in state.items():
        normalized = str(key).removeprefix("module.")
        if normalized.startswith(("teacher.", "caltime.")):
            continue
        converted[normalized] = value
    result = model.load_state_dict(converted, strict=False)
    if result.missing_keys or result.unexpected_keys:
        raise ModelError("RIFE checkpoint keys do not match IFNet 4.25.lite")
    model.eval().to("cuda")

    def run(left: Any, right: Any, timestep: float) -> Any:
        height, width = left.shape[:2]
        frames = np.stack([left, right])
        tensor = torch_module.from_numpy(np.ascontiguousarray(frames)).permute(0, 3, 1, 2)
        tensor = tensor.to("cuda", non_blocking=True).float().div_(255.0)
        multiple = 128
        pad_h = ((height + multiple - 1) // multiple) * multiple - height
        pad_w = ((width + multiple - 1) // multiple) * multiple - width
        if pad_h or pad_w:
            tensor = torch_module.nn.functional.pad(tensor, (0, pad_w, 0, pad_h))
        with torch_module.inference_mode(), torch_module.autocast(
            device_type="cuda", dtype=torch_module.float16, enabled=use_fp16
        ):
            _flow, _mask, merged = model(
                torch_module.cat((tensor[0:1], tensor[1:2]), 1),
                timestep,
                [32, 16, 8, 4, 1],
            )
        output = merged[-1][0, :, :height, :width].clamp_(0, 1).mul_(255).round().byte()
        return output.permute(1, 2, 0).cpu().numpy()

    return run


def load_model_adapters(
    assets: PreparedModelAssets,
    *,
    torch_module: Any | None = None,
    use_fp16: bool = True,
) -> tuple[NanoVSRUpscaler, RifeInterpolator]:
    if torch_module is None:
        try:
            import torch as torch_module
        except ImportError as exc:
            raise RuntimeEnvironmentError("PyTorch is unavailable") from exc
    require_cuda(torch_module)
    return (
        NanoVSRUpscaler(_nanovsr_runner(assets, torch_module, use_fp16=use_fp16)),
        RifeInterpolator(_rife_runner(assets, torch_module, use_fp16=use_fp16)),
    )
