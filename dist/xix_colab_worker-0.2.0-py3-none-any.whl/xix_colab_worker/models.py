from __future__ import annotations

import hashlib
import hmac
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import uuid
import zipfile
from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path, PurePosixPath
from types import ModuleType
from typing import Any
from urllib.parse import urlparse
from urllib.request import urlopen

from .errors import WorkerError


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_REVISION_RE = re.compile(r"^(?:[0-9a-f]{40}|v?[0-9]+(?:\.[0-9]+)*(?:\.lite)?)$")
_ALLOWED_HOSTS = frozenset(
    {
        "codeload.github.com",
        "github.com",
        "drive.usercontent.google.com",
    }
)
_RUNTIME_KEYS = frozenset({"python", "torch", "numpy", "opencv"})


class ModelError(WorkerError):
    """A model asset or inference result is invalid."""


class RuntimeEnvironmentError(ModelError):
    """The runtime cannot execute the configured GPU models."""


class ModelOutOfMemory(ModelError):
    """CUDA ran out of memory while processing a temporal chunk."""


@dataclass(frozen=True)
class AssetLock:
    name: str
    url: str
    revision: str
    filename: str
    size_bytes: int
    sha256: str
    kind: str


@dataclass(frozen=True)
class ModelLocks:
    schema_version: int
    runtime: Mapping[str, str]
    assets: Mapping[str, AssetLock]


@dataclass(frozen=True)
class PreparedModelAssets:
    nanovsr_source: Path
    nanovsr_weights: Path
    rife_source: Path
    rife_model: Path
    realesrgan_x2plus: Path | None = None
    realesrgan_x4plus: Path | None = None


def _validate_asset(name: str, raw: object) -> AssetLock:
    if not isinstance(raw, Mapping) or set(raw) != {
        "url",
        "revision",
        "filename",
        "size_bytes",
        "sha256",
        "kind",
    }:
        raise ModelError(f"model lock {name} does not match schema")
    url = raw["url"]
    revision = raw["revision"]
    filename = raw["filename"]
    size_bytes = raw["size_bytes"]
    checksum = raw["sha256"]
    kind = raw["kind"]
    parsed = urlparse(url) if isinstance(url, str) else None
    if parsed is None or parsed.scheme != "https" or parsed.hostname not in _ALLOWED_HOSTS:
        raise ModelError(f"model lock {name} uses an untrusted URL")
    if not isinstance(revision, str) or not _REVISION_RE.fullmatch(revision):
        raise ModelError(f"model lock {name} has an invalid revision")
    if (
        not isinstance(filename, str)
        or not filename
        or Path(filename).name != filename
        or "/" in filename
        or "\\" in filename
    ):
        raise ModelError(f"model lock {name} has an unsafe filename")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or size_bytes <= 0:
        raise ModelError(f"model lock {name} has an invalid size")
    if not isinstance(checksum, str) or not _SHA256_RE.fullmatch(checksum):
        raise ModelError(f"model lock {name} has an invalid checksum")
    if kind not in {"file", "zip"}:
        raise ModelError(f"model lock {name} has an invalid kind")
    return AssetLock(name, url, revision, filename, size_bytes, checksum, kind)


def load_model_locks(path: Path) -> ModelLocks:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelError("model lock file cannot be read") from exc
    if not isinstance(raw, Mapping) or set(raw) != {"schema_version", "runtime", "assets"}:
        raise ModelError("model lock file does not match schema")
    if raw["schema_version"] != 1:
        raise ModelError("model lock schema is unsupported")
    runtime = raw["runtime"]
    if (
        not isinstance(runtime, Mapping)
        or set(runtime) != _RUNTIME_KEYS
        or not all(isinstance(value, str) and value for value in runtime.values())
    ):
        raise ModelError("model runtime policy does not match schema")
    assets_raw = raw["assets"]
    if not isinstance(assets_raw, Mapping) or not assets_raw:
        raise ModelError("model assets are missing")
    assets = {str(name): _validate_asset(str(name), value) for name, value in assets_raw.items()}
    return ModelLocks(1, dict(runtime), assets)


def _file_matches(path: Path, asset: AssetLock) -> bool:
    try:
        if path.stat().st_size != asset.size_bytes:
            return False
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
        return hmac.compare_digest(digest.hexdigest(), asset.sha256)
    except OSError:
        return False


def ensure_asset(
    asset: AssetLock,
    cache_dir: Path,
    *,
    open_url: Callable[[str], Any] = urlopen,
) -> Path:
    downloads = cache_dir / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    target = downloads / asset.filename
    if _file_matches(target, asset):
        return target
    target.unlink(missing_ok=True)
    last_error: Exception | None = None
    for _attempt in range(2):
        temporary = downloads / f".{asset.filename}.{uuid.uuid4().hex}.tmp"
        try:
            digest = hashlib.sha256()
            size = 0
            with open_url(asset.url) as response, temporary.open("xb") as output:
                while chunk := response.read(1024 * 1024):
                    size += len(chunk)
                    digest.update(chunk)
                    output.write(chunk)
                output.flush()
                os.fsync(output.fileno())
            if size != asset.size_bytes or not hmac.compare_digest(digest.hexdigest(), asset.sha256):
                raise ModelError(f"{asset.name} size or checksum does not match lock")
            os.replace(temporary, target)
            return target
        except Exception as exc:
            temporary.unlink(missing_ok=True)
            target.unlink(missing_ok=True)
            last_error = exc
    if isinstance(last_error, ModelError):
        raise last_error
    raise ModelError(f"{asset.name} could not be downloaded") from last_error


def _is_junk_member(path: PurePosixPath) -> bool:
    return "__MACOSX" in path.parts or "__pycache__" in path.parts or path.name in {".DS_Store"}


def extract_archive(archive: Path, destination: Path, *, expected_sha256: str) -> Path:
    marker = destination / ".xix-asset-sha256"
    if destination.is_dir():
        try:
            if marker.read_text(encoding="ascii").strip() == expected_sha256:
                return destination
        except OSError:
            pass
        raise ModelError("existing extracted model directory does not match lock")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.parent / f".{destination.name}.{uuid.uuid4().hex}.tmp"
    temporary.mkdir()
    try:
        with zipfile.ZipFile(archive) as zipped:
            for info in zipped.infolist():
                normalized = info.filename.replace("\\", "/")
                member = PurePosixPath(normalized)
                if member.is_absolute() or ".." in member.parts or not member.parts:
                    raise ModelError("model archive contains an unsafe path")
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ModelError("model archive contains a symbolic link")
                if _is_junk_member(member):
                    continue
                target = temporary.joinpath(*member.parts)
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(info) as source, target.open("xb") as output:
                    shutil.copyfileobj(source, output)
        (temporary / ".xix-asset-sha256").write_text(expected_sha256 + "\n", encoding="ascii")
        os.replace(temporary, destination)
        return destination
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def prepare_model_assets(locks: ModelLocks, cache_dir: Path) -> PreparedModelAssets:
    required = {
        "nanovsr_source",
        "nanovsr_644k",
        "rife_source",
        "rife_425_lite",
        "realesrgan_x2plus",
        "realesrgan_x4plus",
    }
    if set(locks.assets) != required:
        raise ModelError("model asset set does not match worker profile")
    downloaded = {name: ensure_asset(asset, cache_dir) for name, asset in locks.assets.items()}
    extracted = cache_dir / "extracted"
    nano_source = extract_archive(
        downloaded["nanovsr_source"],
        extracted / f"nanovsr-{locks.assets['nanovsr_source'].sha256[:12]}",
        expected_sha256=locks.assets["nanovsr_source"].sha256,
    )
    rife_source = extract_archive(
        downloaded["rife_source"],
        extracted / f"rife-source-{locks.assets['rife_source'].sha256[:12]}",
        expected_sha256=locks.assets["rife_source"].sha256,
    )
    rife_model = extract_archive(
        downloaded["rife_425_lite"],
        extracted / f"rife-model-{locks.assets['rife_425_lite'].sha256[:12]}",
        expected_sha256=locks.assets["rife_425_lite"].sha256,
    )
    return PreparedModelAssets(
        nano_source,
        downloaded["nanovsr_644k"],
        rife_source,
        rife_model,
        downloaded["realesrgan_x2plus"],
        downloaded["realesrgan_x4plus"],
    )


def require_cuda(torch_module: Any) -> None:
    try:
        available = bool(torch_module.cuda.is_available())
    except Exception as exc:
        raise RuntimeEnvironmentError("CUDA availability could not be checked") from exc
    if not available:
        raise RuntimeEnvironmentError("GPU CUDA tidak tersedia; pilih runtime GPU di Colab")


def _is_oom(error: BaseException) -> bool:
    return "out of memory" in str(error).lower() and "cuda" in str(error).lower()


def _frame_array(frames: Sequence[Any]) -> Any:
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeEnvironmentError("NumPy is unavailable") from exc
    array = np.asarray(frames)
    if array.ndim != 4 or array.shape[0] == 0 or array.shape[-1] != 3 or array.dtype != np.uint8:
        raise ModelError("video frames must be non-empty RGB uint8 arrays")
    return np.ascontiguousarray(array)


def _validated_output(output: Any, expected_shape: tuple[int, ...]) -> Any:
    import numpy as np

    array = np.asarray(output)
    if array.shape != expected_shape or not np.issubdtype(array.dtype, np.number):
        raise ModelError("model output shape does not match the requested frames")
    if not np.isfinite(array).all():
        raise ModelError("model output contains non-finite values")
    if array.dtype != np.uint8:
        array = np.clip(np.rint(array), 0, 255).astype(np.uint8)
    return np.ascontiguousarray(array)


def _tile_starts(length: int, tile_size: int, overlap: int) -> tuple[int, ...]:
    if length <= tile_size:
        return (0,)
    stride = tile_size - overlap
    count = (length - overlap + stride - 1) // stride
    last = length - tile_size
    return tuple((index * last) // (count - 1) for index in range(count))


class NanoVSRUpscaler:
    scale = 4

    def __init__(
        self,
        runner: Callable[[Any], Any],
        *,
        tile_width: int = 320,
        tile_height: int = 180,
        tile_overlap: int = 32,
    ):
        if tile_width <= 0 or tile_height <= 0:
            raise ValueError("NanoVSR tile dimensions must be positive")
        if tile_overlap < 0 or tile_overlap >= min(tile_width, tile_height):
            raise ValueError("NanoVSR tile overlap must be smaller than the tile")
        self._runner = runner
        self._tile_width = tile_width
        self._tile_height = tile_height
        self._tile_overlap = tile_overlap

    def _upscale_once(self, source: Any) -> Any:
        expected = (source.shape[0], source.shape[1] * 4, source.shape[2] * 4, 3)
        try:
            output = self._runner(source)
        except Exception as exc:
            if _is_oom(exc):
                raise ModelOutOfMemory("CUDA kehabisan memori saat menjalankan NanoVSR") from exc
            raise
        return _validated_output(output, expected)

    def upscale_sequence(self, frames: Sequence[Any]) -> Any:
        import numpy as np

        source = _frame_array(frames)
        height, width = source.shape[1:3]
        if height <= self._tile_height and width <= self._tile_width:
            return self._upscale_once(source)

        y_starts = _tile_starts(height, self._tile_height, self._tile_overlap)
        x_starts = _tile_starts(width, self._tile_width, self._tile_overlap)
        output = np.empty((source.shape[0], height * 4, width * 4, 3), dtype=np.uint8)
        for y_index, y_start in enumerate(y_starts):
            y_end = min(y_start + self._tile_height, height)
            y_core_start = 0 if y_index == 0 else (
                min(y_starts[y_index - 1] + self._tile_height, height) + y_start
            ) // 2
            y_core_end = height if y_index == len(y_starts) - 1 else (y_end + y_starts[y_index + 1]) // 2
            for x_index, x_start in enumerate(x_starts):
                x_end = min(x_start + self._tile_width, width)
                x_core_start = 0 if x_index == 0 else (
                    min(x_starts[x_index - 1] + self._tile_width, width) + x_start
                ) // 2
                x_core_end = width if x_index == len(x_starts) - 1 else (x_end + x_starts[x_index + 1]) // 2
                tile = source[:, y_start:y_end, x_start:x_end, :]
                enlarged = self._upscale_once(tile)
                tile_y_start = (y_core_start - y_start) * 4
                tile_y_end = (y_core_end - y_start) * 4
                tile_x_start = (x_core_start - x_start) * 4
                tile_x_end = (x_core_end - x_start) * 4
                output[
                    :,
                    y_core_start * 4:y_core_end * 4,
                    x_core_start * 4:x_core_end * 4,
                    :,
                ] = enlarged[:, tile_y_start:tile_y_end, tile_x_start:tile_x_end, :]
        return output


class RealESRGANUpscaler:
    """Stateless, native-scale Real-ESRGAN adapter for individual video frames."""

    temporal = False

    def __init__(
        self,
        runner: Callable[[Any], Any],
        *,
        scale: int,
        tile_width: int = 320,
        tile_height: int = 180,
        tile_overlap: int = 32,
    ):
        if scale not in (2, 4):
            raise ValueError("Real-ESRGAN scale must be 2 or 4")
        if tile_width <= 0 or tile_height <= 0:
            raise ValueError("Real-ESRGAN tile dimensions must be positive")
        if tile_overlap < 0 or tile_overlap >= min(tile_width, tile_height):
            raise ValueError("Real-ESRGAN tile overlap must be smaller than the tile")
        self.scale = scale
        self._runner = runner
        self._tile_width = tile_width
        self._tile_height = tile_height
        self._tile_overlap = tile_overlap

    def _upscale_once(self, frame: Any) -> Any:
        expected = (frame.shape[0] * self.scale, frame.shape[1] * self.scale, 3)
        try:
            output = self._runner(frame)
        except Exception as exc:
            if _is_oom(exc):
                raise ModelOutOfMemory("CUDA kehabisan memori saat menjalankan Real-ESRGAN") from exc
            raise
        return _validated_output(output, expected)

    def upscale_sequence(self, frames: Sequence[Any]) -> Any:
        import numpy as np

        source = _frame_array(frames)
        height, width = source.shape[1:3]
        if height <= self._tile_height and width <= self._tile_width:
            return np.stack([self._upscale_once(frame) for frame in source])

        y_starts = _tile_starts(height, self._tile_height, self._tile_overlap)
        x_starts = _tile_starts(width, self._tile_width, self._tile_overlap)
        output = np.empty(
            (source.shape[0], height * self.scale, width * self.scale, 3),
            dtype=np.uint8,
        )
        for y_index, y_start in enumerate(y_starts):
            y_end = min(y_start + self._tile_height, height)
            y_core_start = 0 if y_index == 0 else (
                min(y_starts[y_index - 1] + self._tile_height, height) + y_start
            ) // 2
            y_core_end = height if y_index == len(y_starts) - 1 else (y_end + y_starts[y_index + 1]) // 2
            for x_index, x_start in enumerate(x_starts):
                x_end = min(x_start + self._tile_width, width)
                x_core_start = 0 if x_index == 0 else (
                    min(x_starts[x_index - 1] + self._tile_width, width) + x_start
                ) // 2
                x_core_end = width if x_index == len(x_starts) - 1 else (x_end + x_starts[x_index + 1]) // 2
                tile = source[:, y_start:y_end, x_start:x_end, :]
                enlarged = np.stack([self._upscale_once(frame) for frame in tile])
                tile_y_start = (y_core_start - y_start) * self.scale
                tile_y_end = (y_core_end - y_start) * self.scale
                tile_x_start = (x_core_start - x_start) * self.scale
                tile_x_end = (x_core_end - x_start) * self.scale
                output[
                    :,
                    y_core_start * self.scale:y_core_end * self.scale,
                    x_core_start * self.scale:x_core_end * self.scale,
                    :,
                ] = enlarged[:, tile_y_start:tile_y_end, tile_x_start:tile_x_end, :]
        return output


class RifeInterpolator:
    def __init__(self, runner: Callable[[Any, Any, float], Any]):
        self._runner = runner

    def interpolate(self, left: Any, right: Any, timestep: Fraction | float) -> Any:
        source = _frame_array([left, right])
        value = float(timestep)
        if not 0 < value < 1:
            raise ModelError("RIFE timestep must be between 0 and 1")
        try:
            output = self._runner(source[0], source[1], value)
        except Exception as exc:
            if _is_oom(exc):
                raise ModelOutOfMemory("CUDA kehabisan memori saat menjalankan RIFE") from exc
            raise
        return _validated_output(output, tuple(source[0].shape))


def _single_child_root(extracted: Path, required: Path) -> Path:
    candidates = [path for path in extracted.iterdir() if path.is_dir() and (path / required).is_file()]
    if len(candidates) != 1:
        raise ModelError(f"model source does not contain {required.as_posix()}")
    return candidates[0]


@contextmanager
def _python_paths(paths: Sequence[Path]):
    values = [str(path) for path in paths]
    sys.path[:0] = values
    try:
        yield
    finally:
        for value in values:
            try:
                sys.path.remove(value)
            except ValueError:
                pass


def _load_module(name: str, path: Path, search_paths: Sequence[Path]) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ModelError(f"model module {path.name} cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    with _python_paths(search_paths):
        spec.loader.exec_module(module)
    return module


def _torch_state(torch_module: Any, path: Path) -> Mapping[str, Any]:
    try:
        state = torch_module.load(path, map_location="cpu", weights_only=True)
    except Exception as exc:
        raise ModelError("model checkpoint cannot be loaded safely") from exc
    if isinstance(state, Mapping):
        for key in ("params_ema", "params", "model_state_dict"):
            nested = state.get(key)
            if isinstance(nested, Mapping):
                return nested
        return state
    raise ModelError("model checkpoint does not contain a state dictionary")


def _nanovsr_runner(assets: PreparedModelAssets, torch_module: Any, *, use_fp16: bool) -> Callable[[Any], Any]:
    import numpy as np

    source_root = _single_child_root(assets.nanovsr_source, Path("models/nanovsr.py"))
    module = _load_module(
        "xix_vendor_nanovsr",
        source_root / "models" / "nanovsr.py",
        [source_root],
    )
    model = module.NanoVSR(num_feat=48, num_blocks=12, deploy=False)
    model.load_state_dict(_torch_state(torch_module, assets.nanovsr_weights), strict=True)
    model.switch_to_deploy()
    model.eval().to("cuda")

    def run(frames: Any) -> Any:
        tensor = torch_module.from_numpy(np.ascontiguousarray(frames)).permute(0, 3, 1, 2)
        tensor = tensor.unsqueeze(0).to("cuda", non_blocking=True).float().div_(255.0)
        with torch_module.inference_mode(), torch_module.autocast(
            device_type="cuda", dtype=torch_module.float16, enabled=use_fp16
        ):
            output = model(tensor)
            # Postprocess while inference tensors may still be modified in place.
            output = output.squeeze(0).clamp_(0, 1).mul_(255).round().byte()
            return output.permute(0, 2, 3, 1).cpu().numpy()

    return run


def _build_realesrgan_model(torch_module: Any, scale: int) -> Any:
    nn = torch_module.nn
    functional = nn.functional

    class ResidualDenseBlock(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.conv1 = nn.Conv2d(64, 32, 3, 1, 1)
            self.conv2 = nn.Conv2d(64 + 32, 32, 3, 1, 1)
            self.conv3 = nn.Conv2d(64 + 32 * 2, 32, 3, 1, 1)
            self.conv4 = nn.Conv2d(64 + 32 * 3, 32, 3, 1, 1)
            self.conv5 = nn.Conv2d(64 + 32 * 4, 64, 3, 1, 1)
            self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        def forward(self, value: Any) -> Any:
            first = self.lrelu(self.conv1(value))
            second = self.lrelu(self.conv2(torch_module.cat((value, first), 1)))
            third = self.lrelu(self.conv3(torch_module.cat((value, first, second), 1)))
            fourth = self.lrelu(self.conv4(torch_module.cat((value, first, second, third), 1)))
            fifth = self.conv5(torch_module.cat((value, first, second, third, fourth), 1))
            return fifth * 0.2 + value

    class RRDB(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.rdb1 = ResidualDenseBlock()
            self.rdb2 = ResidualDenseBlock()
            self.rdb3 = ResidualDenseBlock()

        def forward(self, value: Any) -> Any:
            result = self.rdb3(self.rdb2(self.rdb1(value)))
            return result * 0.2 + value

    class RRDBNet(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            input_channels = 3 * 4 if scale == 2 else 3
            self.scale = scale
            self.conv_first = nn.Conv2d(input_channels, 64, 3, 1, 1)
            self.body = nn.Sequential(*[RRDB() for _ in range(23)])
            self.conv_body = nn.Conv2d(64, 64, 3, 1, 1)
            self.conv_up1 = nn.Conv2d(64, 64, 3, 1, 1)
            self.conv_up2 = nn.Conv2d(64, 64, 3, 1, 1)
            self.conv_hr = nn.Conv2d(64, 64, 3, 1, 1)
            self.conv_last = nn.Conv2d(64, 3, 3, 1, 1)
            self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        def forward(self, value: Any) -> Any:
            if self.scale == 2:
                value = functional.pixel_unshuffle(value, 2)
            features = self.conv_first(value)
            body = self.conv_body(self.body(features))
            features = features + body
            features = functional.interpolate(
                self.conv_up1(features), scale_factor=2, mode="nearest"
            )
            features = functional.interpolate(
                self.conv_up2(features), scale_factor=2, mode="nearest"
            )
            return self.conv_last(self.lrelu(self.conv_hr(features)))

    return RRDBNet()


def _realesrgan_runner(
    weights: Path,
    scale: int,
    torch_module: Any,
    *,
    use_fp16: bool,
) -> Callable[[Any], Any]:
    import numpy as np

    model = _build_realesrgan_model(torch_module, scale)
    model.load_state_dict(_torch_state(torch_module, weights), strict=True)
    model.eval().to("cuda")
    if use_fp16:
        model.half()

    def run(frame: Any) -> Any:
        height, width = frame.shape[:2]
        tensor = torch_module.from_numpy(np.ascontiguousarray(frame)).permute(2, 0, 1)
        tensor = tensor.unsqueeze(0).to("cuda", non_blocking=True).float().div_(255.0)
        pad_h = (2 - height % 2) % 2 if scale == 2 else 0
        pad_w = (2 - width % 2) % 2 if scale == 2 else 0
        if pad_h or pad_w:
            mode = "reflect" if height > 1 and width > 1 else "replicate"
            tensor = torch_module.nn.functional.pad(tensor, (0, pad_w, 0, pad_h), mode=mode)
        with torch_module.inference_mode(), torch_module.autocast(
            device_type="cuda", dtype=torch_module.float16, enabled=use_fp16
        ):
            output = model(tensor)
            output = output[0, :, :height * scale, :width * scale]
            output = output.clamp_(0, 1).mul_(255).round().byte()
            return output.permute(1, 2, 0).cpu().numpy()

    return run


def _rife_runner(assets: PreparedModelAssets, torch_module: Any, *, use_fp16: bool) -> Callable[[Any, Any, float], Any]:
    import numpy as np

    source_root = _single_child_root(assets.rife_source, Path("model/warplayer.py"))
    train_log = assets.rife_model / "train_log"
    ifnet_path = train_log / "IFNet_HDv3.py"
    weights_path = train_log / "flownet.pkl"
    if not ifnet_path.is_file() or not weights_path.is_file():
        raise ModelError("RIFE model archive is incomplete")
    module = _load_module("xix_vendor_rife_ifnet", ifnet_path, [source_root, assets.rife_model])
    model = module.IFNet()
    state = _torch_state(torch_module, weights_path)
    converted = {}
    for key, value in state.items():
        normalized = str(key).removeprefix("module.")
        if normalized.startswith(("teacher.", "caltime.")):
            continue
        converted[normalized] = value
    result = model.load_state_dict(converted, strict=False)
    if result.missing_keys or result.unexpected_keys:
        raise ModelError("RIFE checkpoint keys do not match IFNet 4.25.lite")
    model.eval().to("cuda")

    def run(left: Any, right: Any, timestep: float) -> Any:
        height, width = left.shape[:2]
        frames = np.stack([left, right])
        tensor = torch_module.from_numpy(np.ascontiguousarray(frames)).permute(0, 3, 1, 2)
        tensor = tensor.to("cuda", non_blocking=True).float().div_(255.0)
        multiple = 128
        pad_h = ((height + multiple - 1) // multiple) * multiple - height
        pad_w = ((width + multiple - 1) // multiple) * multiple - width
        if pad_h or pad_w:
            tensor = torch_module.nn.functional.pad(tensor, (0, pad_w, 0, pad_h))
        with torch_module.inference_mode(), torch_module.autocast(
            device_type="cuda", dtype=torch_module.float16, enabled=use_fp16
        ):
            _flow, _mask, merged = model(
                torch_module.cat((tensor[0:1], tensor[1:2]), 1),
                timestep,
                [32, 16, 8, 4, 1],
            )
            # Cropping is a view of an inference tensor, so keep conversion here.
            output = merged[-1][0, :, :height, :width].clamp_(0, 1).mul_(255).round().byte()
            return output.permute(1, 2, 0).cpu().numpy()

    return run


def load_model_adapters(
    assets: PreparedModelAssets,
    *,
    torch_module: Any | None = None,
    use_fp16: bool = True,
    model: str = "nanovsr-644k",
) -> tuple[Any, RifeInterpolator]:
    if torch_module is None:
        try:
            import torch as torch_module
        except ImportError as exc:
            raise RuntimeEnvironmentError("PyTorch is unavailable") from exc
    require_cuda(torch_module)
    if model == "nanovsr-644k":
        upscaler = NanoVSRUpscaler(_nanovsr_runner(assets, torch_module, use_fp16=use_fp16))
    elif model == "realesrgan-x2plus":
        if assets.realesrgan_x2plus is None:
            raise ModelError("Real-ESRGAN x2plus asset is unavailable")
        upscaler = RealESRGANUpscaler(
            _realesrgan_runner(assets.realesrgan_x2plus, 2, torch_module, use_fp16=use_fp16),
            scale=2,
        )
    elif model == "realesrgan-x4plus":
        if assets.realesrgan_x4plus is None:
            raise ModelError("Real-ESRGAN x4plus asset is unavailable")
        upscaler = RealESRGANUpscaler(
            _realesrgan_runner(assets.realesrgan_x4plus, 4, torch_module, use_fp16=use_fp16),
            scale=4,
        )
    else:
        raise ModelError("unsupported upscale model")
    return (
        upscaler,
        RifeInterpolator(_rife_runner(assets, torch_module, use_fp16=use_fp16)),
    )
