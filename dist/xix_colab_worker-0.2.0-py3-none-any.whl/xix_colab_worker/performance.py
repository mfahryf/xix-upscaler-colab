"""Wall-clock diagnostics; encoder waits are not a measurement of GPU utilization."""
from __future__ import annotations

import json
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from .atomic import atomic_write_json


class PerformanceReport:
    def __init__(self) -> None:
        self.started = time.perf_counter()
        self.stages: dict[str, dict[str, float | int]] = {}
        self.outcome = "failed"
        self.encoder = {"codec": "h264", "implementation": "libx264",
                        "preset": "veryfast", "crf": 18, "threads": 2}

    @contextmanager
    def measure(self, stage: str):
        started = time.perf_counter()
        try:
            yield
        finally:
            record = self.stages.setdefault(stage, {"seconds": 0.0, "calls": 0})
            record["seconds"] += time.perf_counter() - started
            record["calls"] += 1

    def finish(self, job_dir: Path) -> None:
        report = {
            "schema_version": 1, "outcome": self.outcome,
            "total_seconds": round(time.perf_counter() - self.started, 6),
            "encoder": self.encoder,
            "stages": {name: {"seconds": round(value["seconds"], 6),
                              "calls": value["calls"]} for name, value in self.stages.items()},
            "notes": "Wall-clock per stage, not GPU utilization. encode_write includes pipe backpressure; "
                     "FFmpeg may encode concurrently with AI. GPU peak is for the worker process lifetime. "
                     "Interpolation/upscale may include control and heartbeat polling. "
                     "Desktop upload and notebook setup before this job are excluded.",
        }
        torch = sys.modules.get("torch")
        try:
            if torch is not None and torch.cuda.is_available():
                report["gpu"] = {"name": torch.cuda.get_device_name(0),
                    "allocated_mib": round(torch.cuda.memory_allocated(0) / 1024**2, 2),
                    "peak_allocated_mib": round(torch.cuda.max_memory_allocated(0) / 1024**2, 2)}
        except Exception:
            # Optional diagnostics must never turn a valid output into a failed job.
            pass
        print("[COLAB-PERF] " + json.dumps(report, ensure_ascii=False), flush=True)
        try:
            directory = job_dir / "work"
            directory.mkdir(parents=True, exist_ok=True)
            atomic_write_json(directory / "performance.json", report)
        except OSError:
            print("[COLAB-PERF] Laporan waktu tidak dapat disimpan ke Drive; lihat ringkasan di atas.", flush=True)
