from __future__ import annotations

import bisect
import shutil
import subprocess
import time
from collections.abc import Callable, Sequence
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any

from .checkpoints import (
    Segment,
    SegmentMetadata,
    build_segment_plan,
    discard_invalid_checkpoints,
    inspect_checkpoints,
    promote_checkpoint,
)
from .errors import MediaError
from .exchange import copy_into_precreated, read_control, validate_precreated_exchange
from .fps import output_timestamps
from .manifest import MAX_DURATION_SECONDS, JobManifest
from .media import VerifiedOutput, mux_audio, probe_frame_timestamps, probe_media, verify_output
from .models import ModelError, ModelOutOfMemory
from .status import Progress, heartbeat, transition


def is_scene_cut(left: Any, right: Any, threshold: float = 0.35) -> bool:
    import numpy as np

    first = np.asarray(left)
    second = np.asarray(right)
    if first.shape != second.shape or first.ndim != 3 or first.shape[-1] != 3:
        raise ModelError("scene-cut frames must have matching RGB shapes")
    step_y = max(1, first.shape[0] // 48)
    step_x = max(1, first.shape[1] // 48)
    difference = np.abs(
        first[::step_y, ::step_x].astype(np.float32)
        - second[::step_y, ::step_x].astype(np.float32)
    ).mean() / 255.0
    return bool(difference >= threshold)


def render_timeline(
    source_frames: Any,
    source_pts: Sequence[Fraction],
    target_pts: Sequence[Fraction],
    interpolator: Any | None,
    *,
    scene_threshold: float = 0.35,
    pulse: Callable[[], None] = lambda: None,
) -> Any:
    import numpy as np

    frames = np.asarray(source_frames)
    if len(frames) != len(source_pts) or not len(frames):
        raise ModelError("decoded frames do not match source timestamps")
    if any(right <= left for left, right in zip(source_pts, source_pts[1:])):
        raise ModelError("source frame timestamps are not strictly increasing")
    rendered = []
    for timestamp in target_pts:
        right_index = bisect.bisect_left(source_pts, timestamp)
        if right_index == 0:
            rendered.append(frames[0])
            pulse()
            continue
        if right_index >= len(source_pts):
            rendered.append(frames[-1])
            pulse()
            continue
        if source_pts[right_index] == timestamp:
            rendered.append(frames[right_index])
            pulse()
            continue
        left_index = right_index - 1
        span = source_pts[right_index] - source_pts[left_index]
        timestep = (timestamp - source_pts[left_index]) / span
        if interpolator is None or is_scene_cut(
            frames[left_index], frames[right_index], scene_threshold
        ):
            rendered.append(frames[left_index if timestep < Fraction(1, 2) else right_index])
        else:
            rendered.append(
                interpolator.interpolate(frames[left_index], frames[right_index], timestep)
            )
        pulse()
    return np.ascontiguousarray(np.stack(rendered))


def _upscale_chunks(
    frames: Any,
    upscaler: Any,
    chunk_size: int,
    context: int,
    pulse: Callable[[], None],
) -> Any:
    import numpy as np

    if chunk_size <= context * 2:
        raise ModelError("temporal chunk must be larger than its context")
    core_size = chunk_size - context * 2
    output = []
    for core_start in range(0, len(frames), core_size):
        core_end = min(len(frames), core_start + core_size)
        chunk_start = max(0, core_start - context)
        chunk_end = min(len(frames), core_end + context)
        enlarged = upscaler.upscale_sequence(frames[chunk_start:chunk_end])
        pulse()
        keep_start = core_start - chunk_start
        keep_end = keep_start + (core_end - core_start)
        output.append(enlarged[keep_start:keep_end])
    return np.ascontiguousarray(np.concatenate(output, axis=0))


def upscale_temporal_chunks(
    frames: Any,
    upscaler: Any,
    *,
    chunk_size: int = 15,
    context: int = 2,
    pulse: Callable[[], None] = lambda: None,
) -> Any:
    try:
        return _upscale_chunks(frames, upscaler, chunk_size, context, pulse)
    except ModelOutOfMemory:
        retry_size = max(context * 2 + 1, min(9, chunk_size // 2 + 1))
        if retry_size >= chunk_size:
            raise
        return _upscale_chunks(frames, upscaler, retry_size, context, pulse)


def _ffmpeg() -> str:
    executable = shutil.which("ffmpeg")
    if executable is None:
        raise MediaError("ffmpeg is unavailable")
    return executable


def _ratio(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def _decode_frame_range(
    input_path: Path,
    *,
    start: Fraction,
    count: int,
    width: int,
    height: int,
) -> Any:
    import numpy as np

    if count <= 0:
        raise MediaError("decoded frame range is empty")
    command = [
        _ffmpeg(),
        "-hide_banner",
        "-loglevel",
        "error",
        "-noautorotate",
        "-ss",
        f"{float(start):.9f}",
        "-i",
        str(input_path),
        "-map",
        "0:v:0",
        "-frames:v",
        str(count),
        "-an",
        "-sn",
        "-dn",
        "-pix_fmt",
        "rgb24",
        "-f",
        "rawvideo",
        "pipe:1",
    ]
    try:
        completed = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=180,
            check=False,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MediaError("video segment could not be decoded") from exc
    if completed.returncode != 0:
        raise MediaError("video segment decoding failed")
    frame_bytes = width * height * 3
    expected = count * frame_bytes
    if len(completed.stdout) != expected:
        raise MediaError("decoded frame count does not match source timestamps")
    return np.frombuffer(completed.stdout, dtype=np.uint8).reshape(count, height, width, 3).copy()


def _encode_rgb_frames(
    frames: Any,
    output: Path,
    fps: Fraction,
    *,
    rotation: int,
) -> None:
    import numpy as np

    array = np.ascontiguousarray(frames)
    if array.ndim != 4 or not len(array) or array.shape[-1] != 3 or array.dtype != np.uint8:
        raise MediaError("encoded frames must be non-empty RGB uint8 arrays")
    height, width = array.shape[1:3]
    command = [
        _ffmpeg(),
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s:v",
        f"{width}x{height}",
        "-r",
        _ratio(fps),
        "-i",
        "pipe:0",
        "-an",
        "-c:v",
        "libx264",
        "-preset",
        "medium",
        "-crf",
        "18",
        "-pix_fmt",
        "yuv420p",
    ]
    if rotation:
        command.extend(["-metadata:s:v:0", f"rotate={rotation}"])
    command.extend(["-movflags", "+faststart", str(output)])
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        assert process.stdin is not None
        for frame in array:
            process.stdin.write(memoryview(frame))
        process.stdin.close()
        assert process.stderr is not None
        stderr = process.stderr.read(1024 * 1024)
        process.stderr.close()
        return_code = process.wait(timeout=300)
    except (OSError, subprocess.TimeoutExpired, BrokenPipeError) as exc:
        if "process" in locals():
            process.kill()
        raise MediaError("upscaled segment could not be encoded") from exc
    if return_code != 0:
        raise MediaError("upscaled segment encoding failed")
    if len(stderr) >= 1024 * 1024:
        raise MediaError("upscaled segment encoder returned too much error output")


def _source_range(
    source_pts: Sequence[Fraction], target_pts: Sequence[Fraction]
) -> tuple[int, int]:
    first = bisect.bisect_right(source_pts, target_pts[0]) - 1
    last = bisect.bisect_left(source_pts, target_pts[-1]) + 1
    return max(0, first), min(len(source_pts), max(first + 2, last + 1))


def _segment_targets(
    all_targets: Sequence[Fraction], segment: Segment, context: int = 2
) -> tuple[tuple[Fraction, ...], int, int]:
    core_start = bisect.bisect_left(all_targets, segment.start)
    core_end = bisect.bisect_left(all_targets, segment.end)
    expanded_start = max(0, core_start - context)
    expanded_end = min(len(all_targets), core_end + context)
    if core_start == core_end:
        raise MediaError("segment does not contain an output frame")
    return (
        tuple(all_targets[expanded_start:expanded_end]),
        core_start - expanded_start,
        core_end - expanded_start,
    )


def _make_segment(
    input_path: Path,
    source_pts: Sequence[Fraction],
    all_targets: Sequence[Fraction],
    segment: Segment,
    input_info: Any,
    output_fps: Fraction,
    upscaler: Any,
    interpolator: Any | None,
    output: Path,
    pulse: Callable[[], None],
) -> SegmentMetadata:
    targets, trim_start, trim_end = _segment_targets(all_targets, segment)
    source_start, source_end = _source_range(source_pts, targets)
    local_pts = tuple(source_pts[source_start:source_end])
    decoded = _decode_frame_range(
        input_path,
        start=local_pts[0],
        count=len(local_pts),
        width=input_info.width,
        height=input_info.height,
    )
    pulse()
    timeline = render_timeline(decoded, local_pts, targets, interpolator, pulse=pulse)
    enlarged = upscale_temporal_chunks(timeline, upscaler, pulse=pulse)
    core = enlarged[trim_start:trim_end]
    _encode_rgb_frames(core, output, output_fps, rotation=input_info.rotation)
    pulse()
    media = probe_media(output)
    from .manifest import sha256_file

    return SegmentMetadata(
        index=segment.index,
        source_start=segment.start,
        source_end=segment.end,
        width=media.width,
        height=media.height,
        fps=media.fps,
        duration=media.duration,
        size_bytes=output.stat().st_size,
        sha256=sha256_file(output),
    )


def _concat_segments(paths: Sequence[Path], output: Path, work_dir: Path) -> None:
    if not paths:
        raise MediaError("no verified checkpoints are available")
    concat_file = work_dir / "segments.ffconcat"
    lines = ["ffconcat version 1.0"]
    for path in paths:
        escaped = path.resolve().as_posix().replace("'", "'\\''")
        lines.append(f"file '{escaped}'")
    concat_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    command = [
        _ffmpeg(),
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        str(concat_file),
        "-map",
        "0:v:0",
        "-c",
        "copy",
        "-an",
        str(output),
    ]
    completed = subprocess.run(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        timeout=300,
        check=False,
        shell=False,
    )
    if completed.returncode != 0:
        raise MediaError("verified video segments could not be joined")


class _CancelRequested(Exception):
    pass


class _PauseRequested(Exception):
    pass


class _ControlReader:
    def __init__(self, job_dir: Path) -> None:
        self.job_dir = job_dir
        self.revision = -1
        self.action = "run"
        self.temporary_segment: Path | None = None

    def check(self, *, safe_checkpoint: bool = False) -> None:
        command = read_control(self.job_dir, self.revision)
        if command is not None:
            self.revision = command.revision
            self.action = command.action
        if self.action == "cancel":
            raise _CancelRequested
        if safe_checkpoint and self.action == "pause":
            raise _PauseRequested

    def discard_partial_work(self) -> None:
        work_dir = self.job_dir / "work"
        paths = [work_dir / "joined-silent.mp4", work_dir / "output.mp4"]
        if self.temporary_segment is not None:
            paths.append(self.temporary_segment)
        for path in paths:
            path.unlink(missing_ok=True)


def _validate_source(manifest: JobManifest, input_info: Any) -> None:
    if input_info.duration > Fraction(str(MAX_DURATION_SECONDS)):
        raise MediaError("source exceeds the 1 minute limit")
    expected_duration = Fraction(str(manifest.source.duration_seconds))
    if (
        input_info.width != manifest.source.width
        or input_info.height != manifest.source.height
        or input_info.time_base != manifest.source.time_base
        or input_info.fps != manifest.source.nominal_fps
        or input_info.has_audio != manifest.source.has_audio
        or abs(input_info.duration - expected_duration) >= Fraction(1, 1) / input_info.fps
    ):
        raise MediaError("input media metadata does not match manifest")


def run_pipeline(
    job_dir: Path,
    manifest: JobManifest,
    session_id: str,
    upscaler: Any,
    interpolator: Any | None,
    *,
    segment_seconds: int = 10,
    processing_input_path: Path | None = None,
) -> VerifiedOutput | None:
    validate_precreated_exchange(job_dir)
    control = _ControlReader(job_dir)
    try:
        control.check(safe_checkpoint=True)
        return _run_pipeline(
            job_dir, manifest, session_id, upscaler, interpolator,
            segment_seconds=segment_seconds,
            processing_input_path=processing_input_path,
            control=control,
        )
    except _CancelRequested:
        control.discard_partial_work()
        transition(job_dir, session_id, "cancelled", "Dibatalkan")
        return None
    except _PauseRequested:
        transition(job_dir, session_id, "paused", "Dijeda setelah checkpoint aman")
        return None


def _run_pipeline(
    job_dir: Path,
    manifest: JobManifest,
    session_id: str,
    upscaler: Any,
    interpolator: Any | None,
    *,
    segment_seconds: int,
    processing_input_path: Path | None,
    control: _ControlReader,
) -> VerifiedOutput:
    input_path = processing_input_path or (job_dir / manifest.input.name)
    work_dir = job_dir / "work"
    work_dir.mkdir(parents=True, exist_ok=True)
    transition(job_dir, session_id, "preparing", "Memeriksa input dan checkpoint")
    input_info = probe_media(input_path)
    _validate_source(manifest, input_info)
    source_pts = probe_frame_timestamps(input_path)
    if len(source_pts) < 2:
        raise MediaError("video harus memiliki sedikitnya dua frame")
    output_fps = manifest.interpolation or input_info.fps
    all_targets = tuple(output_timestamps(input_info.duration, output_fps))
    plan = build_segment_plan(input_info.duration, segment_seconds)
    checkpoint_state = inspect_checkpoints(job_dir, plan)
    discard_invalid_checkpoints(job_dir, checkpoint_state)
    transition(job_dir, session_id, "processing", "Memproses video")
    active_segment = checkpoint_state.next_index
    last_pulse = time.monotonic()

    def pulse(force: bool = False) -> None:
        nonlocal last_pulse
        # Commands must not wait for the less frequent heartbeat publication.
        control.check()
        now_mono = time.monotonic()
        if not force and now_mono - last_pulse < 10:
            return
        last_pulse = now_mono
        completed = min(active_segment, len(plan.segments))
        heartbeat(
            job_dir,
            session_id,
            datetime.now(timezone.utc),
            Progress(
                segment_index=completed,
                segment_count=len(plan.segments),
                percent=completed * 100 / len(plan.segments),
                last_checkpoint=completed - 1 if completed else None,
            ),
        )

    if checkpoint_state.next_index:
        heartbeat(
            job_dir,
            session_id,
            datetime.now(timezone.utc),
            Progress(
                segment_index=checkpoint_state.next_index,
                segment_count=len(plan.segments),
                percent=checkpoint_state.next_index * 100 / len(plan.segments),
                last_checkpoint=checkpoint_state.next_index - 1,
            ),
        )
    for segment in plan.segments[checkpoint_state.next_index :]:
        control.check(safe_checkpoint=True)
        active_segment = segment.index
        temporary_segment = work_dir / f"segment-{segment.index:05d}.mp4"
        control.temporary_segment = temporary_segment
        temporary_segment.unlink(missing_ok=True)
        metadata = _make_segment(
            input_path,
            source_pts,
            all_targets,
            segment,
            input_info,
            output_fps,
            upscaler,
            interpolator if manifest.interpolation is not None else None,
            temporary_segment,
            pulse,
        )
        promote_checkpoint(temporary_segment, job_dir, metadata)
        control.temporary_segment = None
        complete = segment.index + 1
        heartbeat(
            job_dir,
            session_id,
            datetime.now(timezone.utc),
            Progress(
                segment_index=complete,
                segment_count=len(plan.segments),
                percent=complete * 100 / len(plan.segments),
                last_checkpoint=segment.index,
            ),
        )
        control.check(safe_checkpoint=True)

    active_segment = len(plan.segments)
    control.check(safe_checkpoint=True)
    pulse(force=True)

    checkpoint_paths = [
        job_dir / "checkpoints" / f"segment-{segment.index:05d}.mp4"
        for segment in plan.segments
    ]
    silent = work_dir / "joined-silent.mp4"
    muxed = work_dir / "output.mp4"
    silent.unlink(missing_ok=True)
    muxed.unlink(missing_ok=True)
    _concat_segments(checkpoint_paths, silent, work_dir)
    pulse()
    mux_audio(input_path, silent, muxed, manifest.mute_audio)
    pulse()
    verified = verify_output(input_info, muxed, manifest.interpolation, manifest.mute_audio)
    control.check(safe_checkpoint=True)
    final_output = job_dir / "output.mp4"
    copy_into_precreated(muxed, final_output)
    control.check(safe_checkpoint=True)
    verified = verify_output(
        input_info,
        final_output,
        manifest.interpolation,
        manifest.mute_audio,
        expected_sha256=verified.sha256,
    )
    control.check(safe_checkpoint=True)
    media = verified.media
    transition(
        job_dir,
        session_id,
        "completed",
        "Selesai",
        output={
            "name": "output.mp4",
            "size_bytes": verified.size_bytes,
            "sha256": verified.sha256,
            "width": media.width,
            "height": media.height,
            "duration_seconds": float(media.duration),
            "fps": _ratio(media.fps),
            "has_audio": media.has_audio,
        },
    )
    return verified
