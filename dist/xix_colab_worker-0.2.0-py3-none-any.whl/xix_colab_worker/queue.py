from __future__ import annotations

import threading
import uuid
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import StatusError, WorkerError
from .exchange import ExchangeError, read_control, validate_precreated_exchange
from .manifest import WORKER_VERSION, JobManifest, load_manifest
from .status import (
    ACTIVE_STATES,
    JobStatus,
    _remove_claim_lock,
    claim_job,
    fail_unclaimed_job,
    heartbeat,
    read_status,
    reconcile_terminal_status,
    transition,
)


@dataclass(frozen=True)
class QueueSummary:
    completed: int = 0
    paused: int = 0
    cancelled: int = 0
    failed: int = 0
    skipped: int = 0


def _internal_failure_message(error: BaseException) -> str:
    detail = str(error).splitlines()[0].strip()[:300]
    if detail:
        return f"Terjadi kegagalan internal pada worker: {type(error).__name__}: {detail}"
    return f"Terjadi kegagalan internal pada worker: {type(error).__name__}"


def _new_session_ids() -> Iterator[str]:
    while True:
        yield str(uuid.uuid4())


class HeartbeatWatchdog:
    def __init__(
        self,
        job_dir: Path,
        session_id: str,
        *,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        interval_seconds: float = 10.0,
    ) -> None:
        if interval_seconds <= 0:
            raise ValueError("heartbeat interval must be positive")
        self._job_dir = job_dir
        self._session_id = session_id
        self._now = now
        self._interval = interval_seconds
        self._stop = threading.Event()
        self._heartbeat_written = threading.Event()
        self._thread: threading.Thread | None = None
        self._error: BaseException | None = None

    def start(self) -> None:
        if self._thread is not None:
            raise RuntimeError("heartbeat watchdog already started")
        self._thread = threading.Thread(target=self._run, name="xix-colab-heartbeat", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        while not self._stop.wait(self._interval):
            try:
                status = read_status(self._job_dir)
                if status.state not in ACTIVE_STATES or status.session_id != self._session_id:
                    return
                heartbeat(
                    self._job_dir,
                    self._session_id,
                    self._now(),
                    status.progress,
                )
                self._heartbeat_written.set()
            except BaseException as exc:
                self._error = exc
                self._stop.set()
                return

    def wait_for_heartbeat(self, timeout: float) -> bool:
        return self._heartbeat_written.wait(timeout)

    def stop(self, *, raise_error: bool = True) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self._interval * 2))
            if self._thread.is_alive():
                raise RuntimeError("heartbeat watchdog did not stop")
        if raise_error and self._error is not None:
            raise self._error


def _job_directories(jobs_dir: Path) -> list[Path]:
    if not jobs_dir.is_dir():
        raise WorkerError("folder jobs tidak ditemukan")
    jobs: list[Path] = []
    try:
        children = list(jobs_dir.iterdir())
    except OSError as exc:
        raise WorkerError("folder jobs tidak dapat dibaca") from exc
    for child in children:
        if child.is_symlink() or not child.is_dir():
            continue
        try:
            parsed = uuid.UUID(child.name)
        except ValueError:
            continue
        if str(parsed) != child.name.lower():
            continue
        jobs.append(child)
    return jobs


def _discover(
    jobs_dir: Path,
    worker_version: str,
    now: datetime,
) -> tuple[list[tuple[Path, JobManifest]], int, int]:
    runnable: list[tuple[Path, JobManifest]] = []
    skipped = 0
    invalid_failed = 0
    for job_dir in _job_directories(jobs_dir):
        try:
            terminal = reconcile_terminal_status(job_dir)
            if terminal is not None:
                skipped += 1
                continue
            status = read_status(job_dir)
            if status.state in {"completed", "failed", "cancelled"}:
                skipped += 1
                continue
            if status.state in ACTIVE_STATES and status.heartbeat_at is not None:
                if (now - status.heartbeat_at).total_seconds() < 60:
                    skipped += 1
                    continue
            manifest = load_manifest(job_dir, worker_version)
            validate_precreated_exchange(job_dir)
            if str(manifest.job_id) != job_dir.name.lower():
                skipped += 1
                continue
        except WorkerError as exc:
            try:
                if not fail_unclaimed_job(job_dir, str(exc)):
                    skipped += 1
                    continue
            except (WorkerError, OSError):
                pass
            invalid_failed += 1
            continue
        runnable.append((job_dir, manifest))
    runnable.sort(key=lambda item: (item[1].created_at, item[0].name))
    return runnable, skipped, invalid_failed


def _pause_if_owned(job_dir: Path, session_id: str) -> None:
    try:
        status = read_status(job_dir)
        if status.session_id == session_id and status.state in ACTIVE_STATES:
            transition(job_dir, session_id, "paused", "Dijeda pada batas aman worker")
    except (WorkerError, OSError):
        pass


def _fail_if_owned(job_dir: Path, session_id: str, message: str) -> None:
    try:
        status = read_status(job_dir)
        if status.session_id == session_id and status.state in ACTIVE_STATES:
            transition(job_dir, session_id, "failed", message)
    except (WorkerError, OSError):
        pass


def _release_claim(job_dir: Path, session_id: str) -> None:
    try:
        _remove_claim_lock(job_dir, session_id)
    except WorkerError:
        pass


def _count_terminal(status: JobStatus) -> tuple[int, int, int, int]:
    return (
        int(status.state == "completed"),
        int(status.state == "paused"),
        int(status.state == "cancelled"),
        int(status.state == "failed"),
    )


def run_queue(
    jobs_dir: Path,
    processor: Callable[[Path, JobManifest, str], Any],
    *,
    worker_version: str = WORKER_VERSION,
    now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    session_ids: Iterator[str] | None = None,
) -> QueueSummary:
    current_time = now()
    runnable, skipped, invalid_failed = _discover(jobs_dir, worker_version, current_time)
    completed = paused = cancelled = 0
    failed = invalid_failed
    ids = session_ids if session_ids is not None else _new_session_ids()
    for job_dir, manifest in runnable:
        try:
            session_id = next(ids)
        except StopIteration as exc:
            raise WorkerError("worker session ID tidak tersedia") from exc
        try:
            claim_time = now()
            validate_precreated_exchange(job_dir)
            claim_job(job_dir, session_id, claim_time)
        except (ExchangeError, OSError):
            _release_claim(job_dir, session_id)
            failed += 1
            continue
        except StatusError:
            skipped += 1
            continue
        watchdog = HeartbeatWatchdog(job_dir, session_id)
        watchdog.start()
        interrupted: KeyboardInterrupt | None = None
        failure_message: str | None = None
        try:
            # This admission check precedes CLI model setup. The pipeline owns
            # all subsequent polling and its revision tracking.
            command = read_control(job_dir, after_revision=-1)
            if command is not None and command.action in {"pause", "cancel"}:
                state = "paused" if command.action == "pause" else "cancelled"
                transition(job_dir, session_id, state, "Perintah kontrol sebelum pemrosesan")
            else:
                processor(job_dir, manifest, session_id)
            watchdog.stop()
        except KeyboardInterrupt as exc:
            watchdog.stop(raise_error=False)
            interrupted = exc
        except WorkerError as exc:
            watchdog.stop(raise_error=False)
            failure_message = str(exc)
        except Exception as exc:
            watchdog.stop(raise_error=False)
            failure_message = _internal_failure_message(exc)

        try:
            status = reconcile_terminal_status(job_dir)
            if status is None and interrupted is not None:
                _pause_if_owned(job_dir, session_id)
            elif status is None and failure_message is not None:
                _fail_if_owned(job_dir, session_id, failure_message)
            if status is None:
                status = reconcile_terminal_status(job_dir) or read_status(job_dir)
            if status.state not in {"completed", "paused", "cancelled", "failed"}:
                if interrupted is None:
                    _fail_if_owned(job_dir, session_id, "Worker berhenti tanpa status akhir")
                    status = reconcile_terminal_status(job_dir) or read_status(job_dir)
            completed_delta, paused_delta, cancelled_delta, failed_delta = _count_terminal(status)
            completed += completed_delta
            paused += paused_delta
            cancelled += cancelled_delta
            failed += failed_delta
            if status.state in ACTIVE_STATES:
                if status.session_id != session_id:
                    skipped += 1
                else:
                    failed += 1
        except (WorkerError, OSError):
            failed += 1
        finally:
            _release_claim(job_dir, session_id)
        if interrupted is not None:
            raise interrupted
    return QueueSummary(completed, paused, cancelled, failed, skipped)
