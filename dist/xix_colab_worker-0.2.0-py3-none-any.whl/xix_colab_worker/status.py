from __future__ import annotations

import json
import math
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

from .atomic import atomic_write_json
from .errors import StatusError
from .exchange import TERMINAL_STATES, _EXCHANGE_LOCK, publish_exchange_status, read_exchange_status


HEARTBEAT_INTERVAL_SECONDS = 10
CLAIM_STALE_SECONDS = 60
STATES = frozenset(
    {"queued", "claimed", "preparing", "processing", "paused", "failed", "cancelled", "completed"}
)
ACTIVE_STATES = frozenset({"claimed", "preparing", "processing"})
_TRANSITIONS = {
    "claimed": frozenset({"preparing", "paused", "failed", "cancelled"}),
    "preparing": frozenset({"processing", "paused", "failed", "cancelled"}),
    "processing": frozenset({"paused", "failed", "cancelled", "completed"}),
}
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_STATUS_PAYLOAD_KEYS = frozenset(
    {"state", "session_id", "heartbeat_at", "progress", "message", "metadata"}
)
# Direct slot publication, status writes, and claim operations share one lock.
_STATUS_LOCK = _EXCHANGE_LOCK
_CLAIM_LOCK_NAME = ".xix-claim.lock"


@dataclass(frozen=True)
class Progress:
    segment_index: int = 0
    segment_count: int = 0
    percent: float = 0.0
    last_checkpoint: int | None = None


@dataclass(frozen=True)
class JobStatus:
    state: str = "queued"
    session_id: str | None = None
    heartbeat_at: datetime | None = None
    progress: Progress = field(default_factory=Progress)
    message: str = ""
    metadata: Mapping[str, object] = field(default_factory=dict)


def _utc(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise StatusError("time must include a UTC offset")
    return value.astimezone(timezone.utc)


def _timestamp(value: datetime | None) -> str | None:
    if value is None:
        return None
    return _utc(value).isoformat().replace("+00:00", "Z")


def _parse_timestamp(value: object) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.endswith("Z"):
        raise StatusError("status heartbeat is invalid")
    try:
        return datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as exc:
        raise StatusError("status heartbeat is invalid") from exc


def _validate_session(session_id: str) -> str:
    try:
        uuid.UUID(session_id)
    except (ValueError, AttributeError) as exc:
        raise StatusError("worker session ID must be a UUID") from exc
    return session_id


def _validate_progress(progress: Progress) -> None:
    if isinstance(progress.percent, bool) or not 0 <= progress.percent <= 100:
        raise StatusError("progress must be between 0 and 100")
    if (
        isinstance(progress.segment_index, bool)
        or isinstance(progress.segment_count, bool)
        or not isinstance(progress.segment_index, int)
        or not isinstance(progress.segment_count, int)
        or progress.segment_index < 0
        or progress.segment_count < 0
        or progress.segment_index > progress.segment_count
        or (progress.segment_count == 0 and progress.segment_index != 0)
    ):
        raise StatusError("segment progress is inconsistent")
    if progress.last_checkpoint is not None and (
        isinstance(progress.last_checkpoint, bool)
        or not isinstance(progress.last_checkpoint, int)
        or progress.last_checkpoint < 0
        or progress.last_checkpoint >= progress.segment_count
    ):
        raise StatusError("last checkpoint is inconsistent")


def _safe_message(message: str) -> str:
    lines = str(message).splitlines()
    first_line = (lines[0] if lines else "")[:500]
    first_line = re.sub(r"(?i)\b(?:traceback|token|secret|password)\b(?:\s*[:=]\s*\S+)?", "[redacted]", first_line)
    first_line = re.sub(r"(?:[A-Za-z]:\\|/)(?:[^\s]+[/\\])*[^\s]+", "[path]", first_line)
    return first_line.strip()


def _validate_completed_output(metadata: Mapping[str, object]) -> None:
    output = metadata.get("output")
    if not isinstance(output, Mapping):
        raise StatusError("completed status requires verified output metadata")
    required = {
        "name",
        "size_bytes",
        "sha256",
        "width",
        "height",
        "duration_seconds",
        "fps",
        "has_audio",
    }
    if set(output) != required:
        raise StatusError("completed output metadata is incomplete")
    checksum = output["sha256"]
    if not isinstance(checksum, str) or not _SHA256_RE.fullmatch(checksum):
        raise StatusError("completed output checksum is invalid")
    if output["name"] != "output.mp4":
        raise StatusError("completed output name is invalid")
    for key in ("size_bytes", "width", "height"):
        value = output[key]
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise StatusError("completed output metadata is invalid")
    duration = output["duration_seconds"]
    if (isinstance(duration, bool) or not isinstance(duration, (int, float))
            or not math.isfinite(duration) or duration <= 0):
        raise StatusError("completed output duration is invalid")
    if not isinstance(output["fps"], str) or not re.fullmatch(r"[1-9][0-9]*/[1-9][0-9]*", output["fps"]):
        raise StatusError("completed output FPS is invalid")
    if not isinstance(output["has_audio"], bool):
        raise StatusError("completed output audio flag is invalid")


def _payload(status: JobStatus) -> dict[str, object]:
    return {
        "state": status.state,
        "session_id": status.session_id,
        "heartbeat_at": _timestamp(status.heartbeat_at),
        "progress": {
            "segment_index": status.progress.segment_index,
            "segment_count": status.progress.segment_count,
            "percent": status.progress.percent,
            "last_checkpoint": status.progress.last_checkpoint,
        },
        "message": _safe_message(status.message),
        "metadata": dict(status.metadata),
    }


def _status_from_raw(raw: object) -> JobStatus:
    if not isinstance(raw, dict) or set(raw) != {
        "state",
        "session_id",
        "heartbeat_at",
        "progress",
        "message",
        "metadata",
    }:
        raise StatusError("status.json does not match schema")
    progress_raw = raw["progress"]
    if not isinstance(progress_raw, dict) or set(progress_raw) != {
        "segment_index",
        "segment_count",
        "percent",
        "last_checkpoint",
    }:
        raise StatusError("status progress does not match schema")
    progress = Progress(**progress_raw)
    _validate_progress(progress)
    state = raw["state"]
    if state not in STATES:
        raise StatusError("status state is invalid")
    session_id = raw["session_id"]
    if session_id is not None:
        _validate_session(session_id)
    metadata = raw["metadata"]
    if not isinstance(metadata, dict):
        raise StatusError("status metadata must be an object")
    status = JobStatus(
        state=state,
        session_id=session_id,
        heartbeat_at=_parse_timestamp(raw["heartbeat_at"]),
        progress=progress,
        message=_safe_message(raw["message"]),
        metadata=metadata,
    )
    if status.state == "completed":
        _validate_completed_output(status.metadata)
    return status


def read_status(job_dir: Path) -> JobStatus:
    path = job_dir / "status.json"
    if not path.exists():
        return JobStatus()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise StatusError("status.json cannot be read") from exc
    return _status_from_raw(raw)


def write_status(job_dir: Path, status: JobStatus) -> None:
    with _STATUS_LOCK:
        if status.state not in STATES:
            raise StatusError("status state is invalid")
        _validate_progress(status.progress)
        if status.state == "completed":
            _validate_completed_output(status.metadata)
        payload = _payload(status)
        terminal = reconcile_terminal_status(job_dir)
        if terminal is not None:
            if payload != _payload(terminal):
                raise StatusError("terminal exchange status cannot be changed")
            return
        claim = _read_claim_lock(job_dir)
        if claim is not None and claim[0] != status.session_id:
            raise StatusError("worker session no longer owns this job")
        if status.state in TERMINAL_STATES:
            publish_exchange_status(job_dir, payload)
            atomic_write_json(job_dir / "status.json", payload)
        else:
            atomic_write_json(job_dir / "status.json", payload)
            publish_exchange_status(job_dir, payload)


def fail_unclaimed_job(job_dir: Path, message: str) -> bool:
    with _STATUS_LOCK:
        # Discovery has no authority to revoke any existing claim, even a
        # partially written or stale one. Only claim_job may take it over.
        if _claim_path(job_dir).exists():
            return False
        write_status(job_dir, JobStatus(state="failed", message=message))
        return True


def _claim_path(job_dir: Path) -> Path:
    return job_dir / _CLAIM_LOCK_NAME


def _create_claim_lock(job_dir: Path, session_id: str, now: datetime) -> None:
    payload = json.dumps(
        {"session_id": session_id, "claimed_at": _timestamp(now)},
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    try:
        with _claim_path(job_dir).open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError as exc:
        raise StatusError("job claim lock is already held") from exc
    except OSError as exc:
        raise StatusError("job claim lock cannot be created") from exc


def _remove_claim_lock(job_dir: Path, session_id: str | None) -> bool:
    with _STATUS_LOCK:
        if session_id is None:
            return False
        claim = _read_claim_lock(job_dir)
        if claim is None or claim[0] != session_id:
            return False
        try:
            _claim_path(job_dir).unlink(missing_ok=True)
        except OSError as exc:
            raise StatusError("job claim lock cannot be released") from exc
        return True


def reconcile_terminal_status(job_dir: Path) -> JobStatus | None:
    with _STATUS_LOCK:
        exchange = read_exchange_status(job_dir)
        if exchange is None or exchange["state"] not in TERMINAL_STATES:
            return None
        payload = {key: exchange[key] for key in _STATUS_PAYLOAD_KEYS}
        status = _status_from_raw(payload)
        try:
            atomic_write_json(job_dir / "status.json", _payload(status))
        except OSError:
            pass
        try:
            _remove_claim_lock(job_dir, status.session_id)
        except StatusError:
            # A cleanup failure cannot revoke an already published terminal.
            pass
        return status


def _read_claim_lock(job_dir: Path) -> tuple[str, datetime] | None:
    try:
        raw = json.loads(_claim_path(job_dir).read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or set(raw) != {"session_id", "claimed_at"}:
            raise ValueError("claim lock schema")
        _validate_session(raw["session_id"])
        claimed_at = _parse_timestamp(raw["claimed_at"])
        if claimed_at is None:
            raise ValueError("claim timestamp")
    except FileNotFoundError:
        return None
    except (OSError, ValueError, TypeError, StatusError) as exc:
        raise StatusError("job claim lock is invalid") from exc
    return raw["session_id"], claimed_at


def _require_claim_owner(job_dir: Path, session_id: str) -> None:
    claim = _read_claim_lock(job_dir)
    if claim is None or claim[0] != session_id:
        raise StatusError("worker session no longer owns this job")


def claim_job(job_dir: Path, session_id: str, now: datetime) -> JobStatus:
    with _STATUS_LOCK:
        session_id = _validate_session(session_id)
        now = _utc(now)
        current = reconcile_terminal_status(job_dir) or read_status(job_dir)
        if current.state in {"completed", "failed", "cancelled"}:
            raise StatusError("finished job cannot be claimed")
        if current.state in ACTIVE_STATES and current.heartbeat_at is not None:
            age = (now - current.heartbeat_at).total_seconds()
            if age < CLAIM_STALE_SECONDS:
                raise StatusError("job is already claimed by an active worker")
        claim = _read_claim_lock(job_dir)
        if claim is not None:
            if (now - claim[1]).total_seconds() < CLAIM_STALE_SECONDS:
                raise StatusError("job claim lock is already held")
            if not _remove_claim_lock(job_dir, claim[0]):
                raise StatusError("job claim lock ownership changed")
        _create_claim_lock(job_dir, session_id, now)
        claimed = JobStatus(
            state="claimed",
            session_id=session_id,
            heartbeat_at=now,
            progress=current.progress,
            message="Job claimed",
            metadata=current.metadata,
        )
        try:
            write_status(job_dir, claimed)
        except BaseException:
            try:
                _remove_claim_lock(job_dir, session_id)
            except StatusError:
                pass
            raise
        return claimed


def heartbeat_due(status: JobStatus, now: datetime) -> bool:
    if status.heartbeat_at is None:
        return True
    return (_utc(now) - status.heartbeat_at).total_seconds() >= HEARTBEAT_INTERVAL_SECONDS


def heartbeat(job_dir: Path, session_id: str, now: datetime, progress: Progress) -> JobStatus:
    with _STATUS_LOCK:
        _validate_progress(progress)
        current = reconcile_terminal_status(job_dir) or read_status(job_dir)
        if current.session_id != _validate_session(session_id) or current.state not in ACTIVE_STATES:
            raise StatusError("worker session no longer owns this job")
        _require_claim_owner(job_dir, session_id)
        updated = JobStatus(
            state=current.state,
            session_id=current.session_id,
            heartbeat_at=_utc(now),
            progress=progress,
            message=current.message,
            metadata=current.metadata,
        )
        write_status(job_dir, updated)
        return updated


def transition(
    job_dir: Path,
    session_id: str,
    state: str,
    message: str,
    **metadata: object,
) -> JobStatus:
    with _STATUS_LOCK:
        current = reconcile_terminal_status(job_dir) or read_status(job_dir)
        if current.session_id != _validate_session(session_id):
            raise StatusError("worker session no longer owns this job")
        if state not in _TRANSITIONS.get(current.state, frozenset()):
            raise StatusError("illegal job status transition")
        _require_claim_owner(job_dir, session_id)
        if state == "completed":
            _validate_completed_output(metadata)
        updated = JobStatus(
            state=state,
            session_id=current.session_id,
            heartbeat_at=current.heartbeat_at,
            progress=current.progress,
            message=_safe_message(message),
            metadata=dict(metadata),
        )
        write_status(job_dir, updated)
        if state not in ACTIVE_STATES:
            _remove_claim_lock(job_dir, session_id)
        return updated
